<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Dncontents extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('dncontents', function (Blueprint $table) {
            $table->increments('id');
            $table->string('companyid');
            $table->string('companycode')->nullable();
            $table->string('deliverynoteno');
            $table->string('slno');
            $table->string('description');
            $table->integer('quantity');
            $table->string('created_by')->nullable();
            $table->string('updated_by')->nullable();
            $table->timestamps();
            //$table->primary(['deliverynotno','slno']);
        });
       
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('dncontents');
    }
}
