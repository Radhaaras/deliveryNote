<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Company extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('company', function (Blueprint $table) {
            $table->increments('id');
            $table->string('companyname')->nullable();
            $table->string('companycode')->nullable();
            $table->string('logo')->nullable();
            $table->string('logo_type')->nullable();
            $table->string('p_email')->nullable();
            $table->string('s_email')->nullable();
            $table->string('p_telephone')->nullable();
            $table->string('s_telephone')->nullable();
            $table->string('fax')->nullable();
            $table->string('p_mobile')->nullable();
            $table->string('s_mobile')->nullable();
            $table->string('flat')->nullable();
            $table->string('building')->nullable();
            $table->string('road')->nullable();
            $table->string('block')->nullable();
            $table->string('avenue')->nullable();
            $table->string('city')->nullable();
            $table->string('state')->nullable();
            $table->string('country')->nullable();
            $table->string('address')->nullable();
            $table->date('registered')->nullable();
            $table->date('renewed')->nullable();
            $table->integer('status')->nullable();
            $table->timestamps();
            $table->index(['id']);  
        });
     
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
