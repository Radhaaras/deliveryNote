<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
use App\Model\DeliveryNote;

class Deliverynotes extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('deliverynotes', function (Blueprint $table) {
            $table->increments('id');
            $table->string('companyid');
            $table->string('companycode')->nullable();
            $table->integer('deliverynoteno');
            $table->string('deliverynotecode');
            $table->string('clientno');
            $table->string('projectno');
            $table->string('delivery_date');
            $table->string('invoiceno');
            $table->string('created_by')->nullable();
            $table->string('updated_by')->nullable();
            $table->timestamps();
            $table->index(['id']);  
            $table->unique(['deliverynoteno']);  
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('deliverynotes');
    }
}
