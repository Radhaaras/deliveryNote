<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class UserLogs extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('userlogs', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('companyid')->nullable();
            $table->string('companycode')->nullable();
            $table->string('userid');
            $table->ipAddress('ipaddress');
            $table->string('session_id');
            $table->dateTime('login_at')->nullable();
            $table->dateTime('last_active')->nullable();
            $table->dateTime('logout_at')->nullable();
            $table->integer('status')->nullable();
            $table->timestamps();
            $table->index(['id']);  
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('user_logs');
    }
}
