<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('companyid');
            $table->string('companycode')->nullable();;
            $table->string('fullname');
            $table->string('displayname');
            $table->string('gender');
            $table->string('phone');
            $table->string('otherphone')->nullable(); 
            $table->string('designation')->nullable(); 
            $table->string('email')->unique();
            $table->string('password');  
            $table->string('role')->nullable(); 
            $table->string('cpr')->nullable(); 
            $table->date('cprexpiry')->nullable();
            $table->date('dob')->nullable();
            $table->string('nationality')->nullable();
            $table->string('passportnumber')->nullable();
            $table->date('passportexpiry')->nullable();
            $table->date('visaexpiry')->nullable(); 
            $table->string('dl')->nullable();
            $table->date('dlexpiry')->nullable();  
            $table->string('paddress')->nullable(); 
            $table->string('pcity')->nullable();
            $table->string('pstate')->nullable();
            $table->string('pcountry')->nullable();
            $table->string('ppost')->nullable();
            $table->string('pcountrycode')->nullable();
            $table->string('pphonenumber')->nullable(); 
            $table->string('caddress')->nullable();
            $table->string('ccity')->nullable();  
            $table->string('cstate')->nullable(); 
            $table->string('ccountry')->nullable(); 
            $table->string('cpost')->nullable();
            $table->string('ccountrycode')->nullable(); 
            $table->string('cphonenumber')->nullable();
            $table->string('status')->nullable();
            $table->string('profile_picture')->nullable();
            $table->string('image_type')->nullable();
            $table->string('signature')->nullable();
            $table->string('signature_type')->nullable();
            $table->string('created_by')->nullable();
            $table->string('updated_by')->nullable();
            $table->rememberToken();
            $table->timestamps();
        });
        
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
