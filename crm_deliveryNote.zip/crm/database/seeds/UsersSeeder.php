<?php

use Illuminate\Database\Seeder;
//use Hash; 

class UsersSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run(){
            DB::table('users')->delete();
            //insert some dummy records
            DB::table('users')->insert(
               array( 
                        'id'=>1,
                        'companyid'=>1,
                        'companycode'=>"AKIT", 
                        'fullname'=>'Superadmin', 
                        'displayname'=>'Superadmin', 
                        'gender'=>'Female', 
                        'phone'=>'123456789', 
                        'otherphone'=> '12345678', 
                        'designation'=> 'Superadmin', 
                        'email'=>'radhaursm@gmail.com', 
                        'password'=> bcrypt('123456'),
                        'role'=> 1, 
                        'cpr'=>NULL, 
                        'cprexpiry'=> NULL, 
                        'dob'=>NULL,
                        'nationality'=>NULL,
                        'passportnumber'=>NULL, 
                        'passportexpiry'=>NULL, 
                        'visaexpiry'=>NULL, 
                        'dl'=>NULL, 
                        'dlexpiry'=>NULL,
                        'paddress'=> NULL, 
                        'pcity'=> NULL,
                        'pstate'=> NULL, 
                        'pcountry'=> NULL, 
                        'ppost'=> NULL, 
                        'pcountrycode'=> NULL, 
                        'pphonenumber'=> NULL,
                        'caddress'=> NULL,
                        'ccity'=> NULL,
                        'cstate'=> NULL,
                        'ccountry'=> NULL,
                        'cpost'=> NULL,
                        'ccountrycode'=> NULL, 
                        'cphonenumber'=> NULL,
                        'status'=> 1, 
                        'profile_picture'=> '', 
                        'image_type'=> NULL, 
                        'remember_token'=> NULL, 
                        'created_by'=> 'system', 
                        'Updated_by'=> 'system', 
                        'remember_token'=>bcrypt('123456'),
                        'created_at'=>date('Y-m-d H:i:s'), 
                        'updated_at'=>date('Y-m-d H:i:s')
                    )               
            );
        }
}
