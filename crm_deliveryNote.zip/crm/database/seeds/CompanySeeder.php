<?php

use Illuminate\Database\Seeder;

class CompanySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //DB::table('company')->delete();
        //insert some dummy records
        DB::table('company')->insert(array(
            array(
                'id'=>1,
                'companyname'=>'Abu Kamal Information Technology',
                'companycode'=>'AKIT', 
                'logo'=>'public/img/logo/logo.png',
                'logo_type'=>'png',
                `p_email`=>'', 
                `s_email`=>'', 
                `p_telephone`=>'', 
                `s_telephone`=>'', 
                `fax`=>'', 
                `p_mobile`=>'', 
                `s_mobile`=>'', 
                `flat`=>'',
                `building`=>'', 
                `road`=>'', 
                `block`=>'', 
                `avenue`=>'', 
                `city`=>'', 
                `state`=>'', 
                `country`=>'', 
                `address`=>'', 
                `registered`=>date('Y-m-d H:i:s'),
                `renewed`=>date('Y-m-d H:i:s'),
                `status`=>1, 
                'created_at'=>date('Y-m-d H:i:s'),
                'updated_at'=>date('Y-m-d H:i:s'), 
                'registered'=>date('Y-m-d H:i:s'),
                'renewed'=>date('Y-m-d H:i:s'),
                'status'=>'1',
                                    
            )  
            )         
        );
    }
}
