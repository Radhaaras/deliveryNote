<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        Eloquent::unguard();

        //call uses table seeder class
        $this->call('UsersSeeder');
        //this message shown in your terminal after running db:seed command
        $this->command->info("Users table seeded... :)");
        $this->call('RolesSeeder');
        //this message shown in your terminal after running db:seed command
        $this->command->info("Roles table seeded... :)");
        $this->call('RolePermissionsSeeder');
        //this message shown in your terminal after running db:seed command
        $this->command->info("Role Permissioons table seeded... :)");
        $this->call('CompanySeeder');
        //this message shown in your terminal after running db:seed command
        $this->command->info("Company table seeded... :)");
        
    }
}
