<!DOCTYPE html>
@extends('layouts.app')

@section('content')
<script>


$(document).ready(function() {
	var role=$('#roleselect').val();
		if(role!=''){
			$.ajax({
				type: 'POST',
				url: "{{ route('update.role.ajax') }}",
				data: {'roleselected':role,"_token": "{{ csrf_token() }}", },
				dataType: "json",
				success: function( data ) {
					viewGenerator(data);
				}       
			})
		}



	function readURL(input) {
		console.log(input);
        if (input.files && input.files[0]) {
			console.log('yes');
            var reader = new FileReader();
            
            reader.onload = function (e) {
				$('#profile_pic1').attr('src', e.target.result);
            }
            
            reader.readAsDataURL(input.files[0]);
			$('#deleteImage').removeAttr('hidden');
        }
    }
    
    $("#upload_dp").change(function(){
        readURL(this);
    });

	
	$(function (){
		
		$('#deleteImage').on('click', function(){
			console.log($('#profile_pic1').attr('src'));	
			$('#upload_dp').val('');
			var gender=$("#gender").val();

			if(gender=='male'){
				$('#profile_pic1').attr('src', '/assets/img/profiles/male-user.jpg');	
			}
			else if(gender=='female'){
				$('#profile_pic1').attr('src', '/assets/img/profiles/female-user.jpg');	
			}
			//$('#blah').attr('src', '/assets/img/profiles/user.jpg');
			
			$('#deleteImage').attr("hidden", true);
			var userid=$('#userid').val();
			$.ajax({
					type: 'POST',
					url: "{{ route('edit.delete.dp.ajax') }}",
					data: {'userid':userid,"_token": "{{ csrf_token() }}", },
					dataType: "json",
					success: function( data ) {
						
					}       
				})
			
			
		})
   })
});


$(function(){ // this will be called when the DOM is ready
        $('#roleselect').on('change', function(){
            var role=$('#roleselect').val();
			if(role!=''){
				$.ajax({
					type: 'POST',
					url: "{{ route('update.role.ajax') }}",
					data: {'roleselected':role,"_token": "{{ csrf_token() }}", },
					dataType: "json",
					success: function( data ) {
						viewGenerator(data);
					}       
				})
			}
		});
    });
   
    function viewGenerator(data){
        $("#tabledisplay").empty()
        var pkt = $.parseJSON(JSON.stringify(data));
        roles=pkt[0]['role'];
        rolepermission=pkt[0]['roleprm'];
		var rolelength=Object.keys(roles).length;
		var roleplength=Object.keys(rolepermission).length;
		console.log(roles);
		console.log(rolepermission);
		//console.log(rolepermission)->menuid;
        var tmp=['Project','Estimate','Quotation','Invoice','Joborder','Delivery Note','Payment and  Receipt','Clients','Reports','Employee','Settings','Supervisor'];
        var access=['selectall','view','create','edit','print','delete'];
        if(roleplength>0){
			var pktdump="<h4>Permission Assigned to this Role</h4><table class='table'><thead><tr><th>Access to</th><th style='width: 7%;' class='text-center'>Select All</th><th style='width: 7%;' class='text-center'>View</th><th style='width: 7%;' class='text-center'>Create</th><th style='width: 7%;' class='text-center'>Edit</th><th style='width: 7%;' class='text-center'>Print</th><th style='width: 7%;' class='text-center'>Delete</th> </tr></thead><tbody>";
			
		}
		console.log('roleplength'+roleplength);
		for(var i=0;i<roleplength;i++){
			if(rolepermission[i]['menuid']==10 || rolepermission[i]['menuid']==11){
					pktdump+="<tr><td class='v-align-middle'>"+tmp[rolepermission[i]['menuid']]+"</td>";
					if(rolepermission[i]['selectall']==1){
						pktdump+="<td class='v-align-middle'><label class='show-role'><i class='material-icons allowed'>check</i></label></td>";
			
					}
					else{
						pktdump+="<td class='v-align-middle'><label class='show-role'><i class='material-icons not-allowed'>error_outline</i></label></td>";
					}
			}
			else{
			console.log(rolepermission[i]['menuid'])
			pktdump+="<tr><td class='v-align-middle'>"+tmp[rolepermission[i]['menuid']]+"</td>";
			if(rolepermission[i]['selectall']==1){
				pktdump+="<td class='v-align-middle'><label class='show-role'><i class='material-icons allowed'>check</i></label></td>";
	
			}
			else{
				pktdump+="<td class='v-align-middle'><label class='show-role'><i class='material-icons not-allowed'>error_outline</i></label></td>";
			}
			if(rolepermission[i]['view']==1){
				pktdump+="<td class='v-align-middle'><label class='show-role'><i class='material-icons allowed'>check</i></label></td>";
	
			}
			else{
				pktdump+="<td class='v-align-middle'><label class='show-role'><i class='material-icons not-allowed'>error_outline</i></label></td>";
			}
			if(rolepermission[i]['create']==1){
				pktdump+="<td class='v-align-middle'><label class='show-role'><i class='material-icons allowed'>check</i></label></td>";
	
			}
			else{
				pktdump+="<td class='v-align-middle'><label class='show-role'><i class='material-icons not-allowed'>error_outline</i></label></td>";
			}
			if(rolepermission[i]['edit']==1){
				pktdump+="<td class='v-align-middle'><label class='show-role'><i class='material-icons allowed'>check</i></label></td>";
	
			}
			else{
				pktdump+="<td class='v-align-middle'><label class='show-role'><i class='material-icons not-allowed'>error_outline</i></label></td>";
			}
			if(rolepermission[i]['print']==1){
				pktdump+="<td class='v-align-middle'><label class='show-role'><i class='material-icons allowed'>check</i></label></td>";
	
			}
			else{
				pktdump+="<td class='v-align-middle'><label class='show-role'><i class='material-icons not-allowed'>error_outline</i></label></td>";
			}
			if(rolepermission[i]['delete']==1){
				pktdump+="<td class='v-align-middle'><label class='show-role'><i class='material-icons allowed'>check</i></label></td>";
	
			}
			else{
				pktdump+="<td class='v-align-middle'><label class='show-role'><i class='material-icons not-allowed'>error_outline</i></label></td>";
			}
		}
			pktdump+="</tr>";

        }//forloop
        $('#tabledisplay').append(pktdump);
		
    }
	$(document).on('click', '.slider-disabled', function () {
		var userStatus=$('#userStatus').val();
		
		var userid=$('#userid').val();
		    	$.ajax({
					type: 'post',
					url: "{{ route('user.status.change.ajax') }}",
					data: {'userstatus':userStatus,'userid':userid,"_token": "{{ csrf_token() }}" },
					dataType: "json",
					success: function( data ) {
						console.log(data);
						location.reload(true);
						if(userStatus=='active'){
							$('#useractivetext').addclass('hidden');
							$('#userdeactivetext').removeclass('hidden');
						}
					},
					error: function (jqXHR, textStatus, errorThrown) {
							var data = $.parseJSON(jqXHR.responseText);
							if (data.errors) {
								var errors = data.errors;
								console.log(errors);	
								$.each(data.errors, function (key, value) {
									//$("#" + key).html(value);
									console.log(value);
									location.reload(true);
								});
								
							}
						}
				})
    		});
	
	


</script>

	
		<div class="page-content">
			<div class="content">
			
				<ul class="breadcrumb">
					<li><a href="{{ route('view.user') }}">&larr; View Users</a>
					</li>
				</ul>

				<div class="page-title m-t-30">
					<h3><i class="fa fa-user-edit"></i> Edit User</h3>
				</div>

				<div class="col-sm-12 col-md-12 col-lg-12">
					<ul class="nav nav-tabs" role="tablist">
						<li class="active">
							<a href="#basicdetails" role="tab" data-toggle="tab" aria-expanded="true"> Basic Details</a>
						</li>
						<li class="">
							<a href="#roles" role="tab" data-toggle="tab"  aria-expanded="false">Roles</a>
						</li>

					</ul>

					<div class="tab-content">
					@if($errors)
						@foreach($errors->getMessages() as $key => $error )
							
						@endforeach
					@endif
						<div class="tab-pane active" id="basicdetails">
							<div id="user-profile" class="row">
                    			<div class="col-sm-12">
									<div class="grid simple">
										<div class="grid-title no-border">
											<h4><i class="far fa-address-card"></i> Basic Details</span></h4>
										</div>
										<div class="grid-body no-border">
											<br>
											<form action="{{ route('edit.user.saving') }}" autocomplete="off" id="form_traditional_validation" class="validate"   method='post' enctype="multipart/form-data">
											{{ csrf_field() }}
											<input type='hidden' name='id' id='userid' value='{{ $data->id }}' />
											<div class="row">
                                        		<div class="col-sm-12 col-md-12 col-lg-2 m-b-30">
													<div class="widget-item edit-user-profile ">
														<div class="tiles">
															<div class="tiles-body no-padding">
                                                                @if($data->profile_picture!='')
                                                                    <img name='display_pic' id='profile_pic1' src="{{ asset($data->profile_picture) }}" alt="">
																	
                                                                @else
                                                                    @if($data->gender!='')
                                                                        @if($data->gender==='male')
                                                                            <img name='display_pic' id='profile_pic1' src="/assets/img/profiles/male-user.jpg" alt="">    
                                                                        @else
                                                                            <img name='display_pic' id='profile_pic1' src="/assets/img/profiles/female-user.jpg" alt="">    
                                                                        @endif                                                                
                                                                    @else
                                                                        <img name='display_pic' id='profile_pic1' src="/assets/img/profiles/user.jpg" alt="">                                                                          
                                                                    @endif                                                             
                                                                @endif
																@if($data->profile_picture!='')
																	<div class='clearfix'></div>
																	<a   class='dp-delete-icon' ><i id='deleteImage' class='far fa-trash-alt'></i></a>
																@else
																	<div class='clearfix'></div>
																	<a   class='dp-delete-icon' ><i id='deleteImage' class='far fa-trash-alt' hidden></i></a>
															    @endif 
																	
																<div class="overlayer bottom-right fullwidth">
																	<div class="overlayer-wrapper">
																		<div class="p-l-20 p-r-20 p-b-20 p-t-20 text-center">

                                                                           <div class="dp-upload-icon"><i class="fa fa-camera"></i></div>
																		   @if($data->profile_picture!='')
																				<input name="upload_dp" type="file" id='upload_dp' class="upload-dp" title="Upload your picture" value='{{ $data->profile_picture }} ' />
																			@else
																				<input name="upload_dp" type="file" id='upload_dp' class="upload-dp" title="Upload your picture"/>
																			@endif
																			<div class="clearfix"></div>
																			
																		</div>
																	</div>
																</div>
																<small class="text-danger error">{{ $errors->first('upload_dp') }}</small>	
															</div>
														</div>
														
														
														<div class="tiles white" >
															<div class="tiles-body">
																<div class="row">
																	<div class="user-comment-wrapper pull-left">

																		<div class="comment">
																				<div class="user-name text-black semi-bold"> {{ $data->fullname }} {{-- <span class="semi-bold">Arsal</span> --}}</div>
																				<div class="preview-wrapper">{{ $data->designation }}</div>
																		</div>
																				<?php 
																			$rolename='';
																			foreach($role as $rolepkt){
																					if($rolepkt->roleid==$data->role){
																						$rolename=$rolepkt->rolename;
																					}
																				} 
																			?>
																		<div class="user-role"> <a href="user-profile.php"> {{ $rolename }} </a> </div>

																		<div class="clearfix"></div>
																	</div>

																	<div class="clearfix"></div>
																	<div class="p-l-15 p-t-10 p-r-20">
																		<p class="phone">{{ $data->phone }}</p>
																		<p class="email"><a >{{ $data->email }}</a>
																		</p>

																	</div>
																
															</div>
														</div> 
													</div> 
														<div class="col-sm-12">
																<?php
																//echo Auth::User()->id."  ".$data->id."<br>";
																	if((Auth::User()->id != $data->id) && ($data->created_by != 'system')){
/*
																	}
																	else{
																		*/
																?>
															<h4>Disable this user</h4>
															<div class="row-fluid">
																<label class="disabled-switch">
																
																@if ($data->status == '1')
																<input type="checkbox" name="useractive" id='userStatus' {{ old('useractive') ? 'checked' : '' }} value='deactive' >
																
                                                                @else
																<input type="checkbox" name="useractive" id='userStatus' checked value='active'>
																
																 @endif
																	{{-- <input type="checkbox" name='useractive' value="{{ $data->status }}"> --}}
																	<span class="slider-disabled"></span>
																</label>
																
															</div>
															@if ($data->status == '1')
																<div id='useractivetext'> User Enabled</div>
															
															@else
																<div id='userdeactivetext'> User Disabled</div>
															@endif
															<?php } ?>
															
														</div>
													</div>
												</div>




												
													<div class="col-sm-12 col-md-12 col-lg-5 p-l-30 p-r-30">
																					
														<div class="form-group">
															<label class="form-label">Full Name</label>
															<div class="controls">
																<input class="form-control {{  ( $errors->first('fullname') ) ? 'error' : '' }}"  aria-invalid="false"  aria-invalid="" name="fullname" type="text" value="{{ (old('fullname'))?old('fullname'):$data->fullname }}" required>
                                                                <small class="text-danger error">{{ $errors->first('fullname') }}</small>
															</div>
														</div>
														<div class="form-group">
															<label class="form-label">Display Name</label>
															<span class="help">"Preferred name to display"</span>
															<div class="controls">
																<input class="form-control {{  ( $errors->first('displayname') ) ? 'error' : '' }}"  name="displayname" type="text" value="{{ (old('displayname'))?old('displayname'):$data->displayname }}" required>
                                                                <small class="text-danger error">{{ $errors->first('displayname') }}</small>
															</div>
														</div>
														<div class="form-group">
															<label class="form-label">Gender</label>
															<div class="controls">
																<select name="gender" id="gender" class="select1 form-control {{  ( $errors->first('gender') ) ? 'error' : '' }}"  aria-required="true" aria-invalid="false" aria-describedby="form3Gender-error"  required>
																	@if($data->gender=='male')
																	<option  value="">Select</option>
																	<option value="male" selected>Male</option>
																	<option value="female">Female</option>
																	@else
																	<option  value="">Select</option>
																	<option value="male" >Male</option>
																	<option value="female"selected>Female</option>
																	@endif
																</select>
                                                                <small class="text-danger  error">{{ $errors->first('gender') }}</small>
															</div>
														</div>
                                                        <div class="row form-row">
															<div class="col-md-6">
																<label class="form-label">Mobile Number</label>
																<input class="form-control {{  ( $errors->first('phone') ) ? 'error' : '' }}"  name="phone" type="number" value="{{ (old('phone'))?old('phone'):$data->phone }}" required>
                                                                <small class="text-danger error">{{ $errors->first('phone') }}</small>
															</div>
															<div class="col-md-6">
																<label class="form-label">Other Phone</label>
																<input class="form-control" name="otherphone" type="number" value="{{ (old('otherphone'))?old('otherphone'):$data->otherphone }}" >
                                                                <small class="text-danger error">{{ $errors->first('otherphone') }}</small>
															</div>
														</div>
														<div class="form-group">
															<label class="form-label">Email</label>
															<span class="help">"This email ID is going to be the username"</span>
															<div class="controls">
																<input class="form-control {{  ( $errors->first('email') ) ? 'error' : '' }}"  name="email" type="email" value="{{ (old('email'))?old('email'):$data->email }}" required>
                                                                <small class="text-danger error">{{ $errors->first('email') }}</small>
															</div>
														</div>
														{{--<div class="form-group">
															<label class="form-label">Password</label>
															<span class="help">"User can change the password later from their account settings"</span>
															<div class="controls">
																<input class="form-control error" name="password" type="password" required>
                                                                
															</div>
														</div>
                                                        --}}
														<div class="form-group">
															<label class="form-label">Designation</label>
															<div class="controls">
																<input class="form-control  input-append " name="designation" type="text"  placeholder="" value="{{ (old('designation'))?old('designation'):$data->designation }}" >
                                                                <small class="text-danger error">{{ $errors->first('designation') }}</small>
															</div>
														</div>
														
														<div class="form-group">
															<label class="form-label">National ID</label>
															<span class="help">"CPR number"</span>
															<div class="controls">
																<input type="number" class="form-control {{  ( $errors->first('cpr') ) ? 'error' : '' }}" name='cpr' value="{{ (old('cpr'))?old('cpr'):$data->cpr }}"  >
                                                                <small class="text-danger error">{{ $errors->first('cpr') }}</small>
															</div>
														</div>
														
														<div class="form-group">
															<label class="form-label">National ID Expiry Date</label>
															<span class="help">"CPR Expiry Date"</span>
															<div class="controls">
																@if($data->cprexpiry=='1970-01-01')
																	<input class="form-control expdate" name="cprexpiry" type="text"   placeholder="DD-MM-YYYY" value="">
																
																@else
																	<input class="form-control expdate" name="cprexpiry" type="text"   placeholder="DD-MM-YYYY" value="{{ (old('cprexpiry'))?old('cprexpiry'):date('m-d-Y',strtotime($data->cprexpiry)) }}">
																@endif
																<!--<input type="text"  class="form-control expdate  " placeholder="DD-MM-YYYY" name='cprexpiry' value="{{ (old('cprexpiry'))?old('cprexpiry'):$data->cprexpiry }}" >-->
																<small class="text-danger error">{{ $errors->first('crpexpiry') }}</small>
															</div>
														</div>


														

														<div class="form-group">
															<label class="form-label">Date of Birth</label>
															<div class="controls">
																@if($data->dob=='1970-01-01')
																	<input class="form-control expdate" name="dob" type="text"   placeholder="DD-MM-YYYY" value="">
																
																@else
																	<input class="form-control expdate" name="dob" type="text"   placeholder="DD-MM-YYYY" value="{{ (old('dob'))?old('dob'):date('m-d-Y',strtotime($data->dob)) }}">
																@endif

																<!--<input class="form-control  input-append date" name="dob" type="text"  placeholder="DD-MM-YYYY" value="{{ (old('dob'))?old('dob'):$data->dob }}" width="276"  >-->
                                                                <small class="text-danger error">{{ $errors->first('dob') }}</small>
															</div>
														</div>
														
														<div class="form-group">
															<label class="form-label">Nationality</label>
															<div class="controls">
																<input class="form-control " name="nationality" type="text" value="{{ (old('nationality'))?old('nationality'):$data->nationality }}">
                                                                <small class="text-danger error">{{ $errors->first('nationality') }}</small>
															</div>
														</div>
														<div class="form-group">
															<label class="form-label">Passport Number</label>
															<div class="controls">
																<input class="form-control" name="passportnumber" type="text" value="{{ (old('passportnumber'))?old('passportnumber'):$data->passportnumber }}">
                                                                
															</div>
														</div>
														<div class="form-group">
															<label class="form-label">Passport Expiry Date</label>
															<div class="controls">
															@if($data->passportexpiry=='1970-01-01')
																<input class="form-control expdate" name="passportexpiry" type="text"   placeholder="DD-MM-YYYY" value="">
                                                            
															@else
																<input class="form-control expdate" name="passportexpiry" type="text"   placeholder="DD-MM-YYYY" value="{{ (old('passportexpiry'))?old('passportexpiry'):date('m-d-Y',strtotime($data->passportexpiry)) }}">
															@endif
															    <small class="text-danger error">{{ $errors->first('passportexpiry') }}</small>
															
															</div>
														</div>
                                                        
														
													</div>

													<div class="col-sm-12 col-md-12 col-lg-5 p-l-30 p-r-30">
														<div class="form-group">
															<label class="form-label">Visa Valid Until</label>
															<div class="controls">
															@if($data->visaexpiry=='1970-01-01')
																<input class="form-control expdate" name="visaexpiry" type="text"   placeholder="DD-MM-YYYY" value="">
                                                            
															@else
																<input class="form-control expdate" name="visaexpiry" type="text"   placeholder="DD-MM-YYYY" value="{{ (old('visaexpiry'))?old('visaexpiry'): date('m-d-Y',strtotime($data->visaexpiry))  }}">
															@endif

																<!--<input class="form-control expdate" name="visaexpiry" type="text"   placeholder="DD-MM-YYYY" value="{{ (old('visaexpiry'))?old('visaexpiry'):$data->visaexpiry}}">-->
                                                                <small class="text-danger error">{{ $errors->first('visaexpiry') }}</small>
															</div>
														</div>
														<div class="form-group">
															<label class="form-label">Driving License</label>
															<div class="controls">
																<input class="form-control" name="dl" type="text"  value="{{ (old('dl'))?old('dl'):$data->dl }}">
                                                                
															</div>
														</div>
														<div class="form-group">
															<label class="form-label ">Driving License Expiry Date</label>
															<div class="controls">
															@if($data->dlexpiry=='1970-01-01')
																<input class="form-control expdate" name="dlexpiry" type="text"   placeholder="DD-MM-YYYY" value="">
                                                            
															@else
																<input class="form-control expdate" name="dlexpiry" type="text"   placeholder="DD-MM-YYYY" value="{{ (old('dlexpiry'))?old('dlexpiry'):date('m-d-Y',strtotime($data->dlexpiry)) }}">
															@endif


																<!--<input class="form-control expdate" name="dlexpiry" type="text"   placeholder="DD-MM-YYYY" value="{{ (old('dlexpiry'))?old('dlexpiry'):$data->dlexpiry }}" >-->
                                                                <small class="text-danger error">{{ $errors->first('dlexpiry') }}</small>
															</div>
														</div>
														<br>
														<h4>Permanent Address</h4>
														<div class="row form-row">
															<div class="col-md-12">
																<label class="form-label">Address</label>
																<input class="form-control" name="paddress" type="text" value="{{ (old('paddress'))?old('paddress'):$data->paddress }}" >
                                                               
															</div>
														</div>
														<div class="row form-row">
															<div class="col-md-6">
																<label class="form-label">City</label>
																<input class="form-control" name="pcity" type="text"  value="{{ (old('pcity'))?old('pcity'):$data->pcity }}">
                                                                
															</div>
															<div class="col-md-6">
																<label class="form-label">State</label>
																<input class="form-control" name="pstate" type="text"  value="{{ (old('pstate'))?old('pstate'):$data->pstate }}">
                                                                
															</div>
														</div>
														<div class="row form-row">
															<div class="col-md-8">
																<label class="form-label">Country</label>
																<input class="form-control" name="pcountry" type="text"  value="{{ (old('pcountry'))?old('pcountry'):$data->pcountry }}">
                                                                
															</div>
															<div class="col-md-4">
																<label class="form-label">Postal Code</label>
																<input class="form-control" name="ppost" type="number" value="{{ (old('ppost'))?old('ppost'):$data->ppost }}">
                                                                
															</div>
														</div>
														<div class="row form-row">
															<div class="col-md-4">
																<label class="form-label">Country Code</label>
																<input class="form-control {{  ( $errors->first('pcountrycode') ) ? 'error' : '' }}" name="pcountrycode" type="number" value="{{ (old('pcountrycode'))?old('pcountrycode'):$data->pcountrycode }}">
                                                                <small class="text-danger error">{{ $errors->first('pcountrycode') }}</small>
															</div>
															<div class="col-md-8">
																<label class="form-label">Phone Number</label>
																<input class="form-control {{  ( $errors->first('pphonenumber') ) ? 'error' : '' }}" name="pphonenumber" type="number" value="{{ (old('pphonenumber'))?old('pphonenumber'):$data->pphonenumber }}">
                                                                <small class="text-danger error">{{ $errors->first('pphonenumber') }}</small>
															</div>
														</div>



														<br>
														<h4>Current Addess</h4>
														<div class="row form-row">
															<div class="col-md-12">
																<label class="form-label">Address</label>
																<input class="form-control" name="caddress" type="text"  value="{{ (old('caddress'))?old('caddress'):$data->caddress }}">
                                                               
															</div>
														</div>
														<div class="row form-row">
															<div class="col-md-6">
																<label class="form-label">City</label>
																<input class="form-control" name="ccity" type="text"  value="{{ (old('ccity'))?old('ccity'):$data->ccity }}">
                                                                
															</div>
															<div class="col-md-6">
																<label class="form-label">State</label>
																<input class="form-control" name="cstate" type="text"  value="{{ (old('cstate'))?old('cstate'):$data->cstate }}">
                                                                
															</div>
														</div>
														<div class="row form-row">
															<div class="col-md-8">
																<label class="form-label">Country</label>
																<input class="form-control" name="ccountry" type="text"  value="{{ (old('ccountry'))?old('ccountry'):$data->ccountry }}">
                                                               
															</div>
															<div class="col-md-4">
																<label class="form-label">Postal Code</label>
																<input class="form-control" name="cpost" type="text" value="{{ (old('cpost'))?old('cpost'):$data->cpost }}">
                                                                
															</div>
														</div>
                                                        <div class="row form-row">
															<div class="col-md-4">
																<label class="form-label">Country Code</label>
																<input class="form-control {{  ( $errors->first('ccountrycode') ) ? 'error' : '' }}" name="ccountrycode" type="number" value="{{ (old('ccountrycode'))?old('ccountrycode'):$data->ccountrycode }}">
                                                                <small class="text-danger error">{{ $errors->first('ccountrycode') }}</small>
															</div>
															<div class="col-md-8">
																<label class="form-label">Phone Number</label>
																<input class="form-control {{  ( $errors->first('cphonenumber') ) ? 'error' : '' }}" name="cphonenumber" type="number" value="{{ (old('cphonenumber'))?old('cphonenumber'):$data->cphonenumber }}">
                                                                <small class="text-danger error">{{ $errors->first('cphonenumber') }}</small>
															</div>
														</div>


													</div>


													<div class="col-sm-12 m-t-50 m-b-30">
														<button type="submit" class="btn btn-primary btn-cons pull-right" name='form1'><i class="fa fa-save"></i> Save</button>
													</div>

												</form>

											</div>
										</div>
									</div>
								</div>

							</div>
						</div>


						<div class="tab-pane" id="roles">
							<div class="row">
								<div class="col-sm-12">
									<div class="grid simple">
										<div class="grid-title no-border">
											<h4><i class="fa fa-plug"></i> Roles</span></h4>
										</div>
										<div class="grid-body no-border">
											<br>
											<div class="row">
												

													<div class="col-sm-12 col-md-12 col-lg-4 p-l-30 p-r-30">
													<form action="{{ route('edit.user.saving') }}" id="form_traditional_validation" class="validate" method='post' enctype="multipart/form-data">
													{{ csrf_field() }}
													
													<input type='hidden' name='userid' value='{{ $data->id }}' />								
														<h4>Choose a role to asign for this user</h4>
														<div class="form-group">
															<div class="controls">
																<select name="roleselect" id="roleselect" class="select1 form-control" aria-required="true" aria-invalid="false" aria-describedby="form3Gender-error" required>
																	@if($data->role>0)
																		<option selected>Select</option>
																		<?php	
																			foreach($roleTable as $roles){
																				
																				if($data->role==$roles->roleid){
																					echo "<option selected value=".$roles->roleid .">".$roles->rolename."</option>";
																				}
																				else{
																					echo "<option value=".$roles->roleid .">".$roles->rolename."</option>";
																				}
																				
																			}
																		?>	
																	@else
																	<option selected>Select</option>
																		<?php	
																			foreach($roleTable as $roles){
																				echo "<option value=".$roles->roleid .">".$roles->rolename."</option>";
																			}
																		?>	
																	@endif
																	
																</select>
															</div>
														</div>
														<button type="submit" class="btn btn-primary btn-cons" name='form2'><i class="fa fa-save"></i> Save</button>

													</div>
</form>

													<div class="col-sm-12 col-md-12 col-lg-8 p-l-30 p-r-30">
														
														<div id='tabledisplay'></div>
													</div>


											</div>
										</div>
									</div>
								</div>
							</div>
						</div>


					</div>
				</div>




			</div>
		</div>




	</div>
	


	


@endsection
</body>
</html>