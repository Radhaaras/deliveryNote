
@extends('layouts.app')
@section('content')
<script>
var items = [];
$(document).ready(function(){
	$('.checkAll').click(function(event) {  //on click 
		var $boxes = $(this).closest('tr').find('input[type="checkbox"]');  
		if(this.checked) { // check select status
			$boxes.each(function() { //loop through each checkbox
				this.checked = true;  //select all checkboxes                
			});
		}else{
			$boxes.each(function() { //loop through each checkbox
				this.checked = false; //deselect all checkboxes under the checkAll checkbox                      
			});         
		}
	});
	$('.checkNone').click(function(event) {  //on click 
	var i=0;
		$(this).closest('tr').find('.checkNone').each(function() { //loop through each checkbox
			//console.log(i);
			if(this.checked){
				i=i+1;
			}
			if(i==5){
				$(this).parent().parent().parent().find('input:checkbox:first').prop( "checked",true);
			}
			else{
				$(this).parent().parent().parent().find('input:checkbox:first').prop( "checked",false);
			}			
		}); 
	});
	
})


</script>
	<div class="page-content">
			<div class="content">
				@if (session()->has('success'))
					<div class='alert alert-success'>
						<span class="invalid-feedback" role="alert">
							<strong >{{ session()->get('success') }}</strong>
						</span>
					</div>
					@endif
					
				<div id="role-settings" class="row">
					<div class="container">
						<div class="page-title">
						<h3><i class="fa fa-bolt"></i> Edit Role</h3>
					</div>
					<form action="{{ route('edit.role.saving') }}" id="form_traditional_validation" method='post' class="validate" enctype="multipart/form-data" >	
						@csrf						
								<input type='hidden'  name='roleid' value='{{ $roleid }}'/>
												
						<div class="col-sm-12">
						  <div class="grid simple ">

							<div class="grid-body no-border role-creating-table">
								<input type="text" class="role-name" placeholder="Type a new role name" id='role_name' name='role_name' required minlength="4" maxlength="10" value="{{ (old('role_name'))?old('role_name'):$role[0]->rolename }}" />
								<p><small class="text-danger error">{{ $errors->first('role_name') }}</small></p>
							  <table class="table">
								<thead>
								  <tr>
									<th style="width: 15%;">Full Control</th>
									<th>Access to</th>
									<th style="width: 7%;" class="text-center">View</th>
									<th style="width: 7%;" class="text-center">Create</th>
									<th style="width: 7%;" class="text-center">Edit</th>
									<th style="width: 7%;" class="text-center">Print</th>
									<th style="width: 7%;" class="text-center">Delete</th>
								  </tr>
								</thead>
								<tbody>
								<?php 
									
									//print_r($roleper); 
									$access=['dashboard','project','estimate','quotation','invoice','joborder','dnote','pr','clients','reports','employee','settings'];
									$headdings=['Dashboard','Projects','Estimation','Quotation','Invoice','Job Order','Delivery Note','Payment Receipt','Clients','Reports','Employee Management','Settings','Supervisor'];
									$value=['all','view','create','edit','print','delete'];
									//print_r($roleper);
									$supervisor=0;
									for($i=0;$i<count($access);$i++){
										
										$found=0;
										$text=$access[$i];
										foreach($roleper as $rolepermission){
											//print_r($rolepermission);
										//	echo $rolepermission->supervisor."<br>";
											if($rolepermission->supervisor>0){
												if($supervisor==0){
													$supervisor=1;
												}
											}
											if($rolepermission->menuid==$i){
												$found=1;
												echo "<tr>
												<td class='v-align-middle'>
													<label class='create-role-switch'>";
														if($rolepermission->selectall=='1'){		
															echo "<input type='checkbox'  name='".$text."[0]'  id='".$text."[0]' value='all' class='checkAll' checked>";
														}
														else{
															echo "<input type='checkbox'  name='".$text."[0]'  id='".$text."[0]' value='all' class='checkAll' >";
														}
														echo "<span class='slider-create-role' ></span>
													</label>
												</td>	
												<td class='v-align-middle'>".$headdings[$i]."</td>";
												if($i<11)
													{
													for($j=1;$j<6;$j++){
														$aces=$value[$j];
														
														if($rolepermission->$aces==0){
															echo "<td class='v-align-middle'>
																<label class='create-role-switch'>
																	<input type='checkbox' name='".$text."[".$j."]' id='".$text."[".$j."]' value='".$value[$j]."' class='checkNone'>
																	<span class='slider-create-role'></span>
																</label>  
															</td>";
		
														}
														else{
															echo "<td class='v-align-middle'>
																<label class='create-role-switch'>
																	<input type='checkbox' name='".$text."[".$j."]' id='".$text."[".$j."]' value='".$value[$j]."' class='checkNone' checked>
																	<span class='slider-create-role'></span>
																</label>  
															</td>";
		
														}
													}
												}
												
												
											}
										}
										if($found==0){
											echo "<tr>
											<td class='v-align-middle'>
												<label class='create-role-switch'>";
													echo "<input type='checkbox'  name='".$text."[0]'  id='".$text."[0]' value='all' class='checkAll' >";
													echo "<span class='slider-create-role' ></span>
												</label>
											</td>	
											<td class='v-align-middle'>".$headdings[$i]."</td>";
											if($i<11){
												for($j=1;$j<6;$j++){
													
													echo "<td class='v-align-middle'>
														<label class='create-role-switch'>
															<input type='checkbox' name='".$text."[".$j."]' id='".$text."[".$j."]' value='".$value[$j]."' class='checkNone'>
															<span class='slider-create-role'></span>
														</label>  
													</td>";															
												}
											}
										}
										echo "<tr>";	
									}
									if($supervisor==1){
										echo "<tr>
										<td class='v-align-middle'>
										<label class='create-role-switch'>
											<input type='checkbox'  name='supervisor[0]'  id='supervisor[0]' checked>
											<span class='slider-create-role'></span>
										</label>
									</td>

									<td class='v-align-middle'>Supervisor</td>
									</tr>";

									}
									else{
										echo "<tr>
										<td class='v-align-middle'>
										<label class='create-role-switch'>
											<input type='checkbox'  name='supervisor[0]'  id='supervisor[0]'>
											<span class='slider-create-role'></span>
										</label>
									</td>

									<td class='v-align-middle'>Supervisor</td>
									</tr>";


									}
							
								?>
								</tbody>
							  </table>
								
								<!--<a href="" class="btn btn-save pull-right">Save</a>-->
								<button type='submit' class="btn btn-save pull-right">Save</a>
								
							</div>
						  </div>
						</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
@endsection
</body>
</html>