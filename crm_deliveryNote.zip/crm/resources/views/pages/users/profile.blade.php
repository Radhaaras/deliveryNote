<!DOCTYPE html>
<meta http-equiv="content-type" content="text/html;charset=UTF-8"/>
	<meta charset="utf-8"/>
	<title>QUOFLY - Enterprise Resource Planning, ERP System</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
	<meta content="" name="Enterprise Resource Planning, ERP System"/>
	<meta content="" name="AK Information Technology Bahrain"/>
	<link rel="icon" type="image/png" href="../assets/img/favicon.png"/>

	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt" crossorigin="anonymous">
	<link href="../assets/plugins/pace/pace-theme-flash.css" rel="stylesheet" type="text/css" media="screen"/>
	
	<link href="../assets/plugins/bootstrapv3/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
	<link href="../assets/plugins/bootstrapv3/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css"/>
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<link href="../assets/plugins/animate.min.css" rel="stylesheet" type="text/css"/>
	<link href="../assets/plugins/jquery-scrollbar/jquery.scrollbar.css" rel="stylesheet" type="text/css"/>
	<link href="../quofly/css/quofly.css" rel="stylesheet" type="text/css"/>



@extends('layouts.app')

@section('content')
<script>

$(function(){
	jQuery('#tablist a[href="#{{ old('tab') }}"]').tab('show');
	if (location.hash) {
		var hash = window.location.hash;
		jQuery('#tablist a[href="'+hash+'"]').tab('show');
    }
	
	
	// store the currently selected tab in the hash value
	$("ul.nav-tabs > li > a").on("shown.bs.tab", function(e) {
		var id = $(e.target).attr("href").substr(1);
		window.location.hash = id;
	})
})



    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#blah')
                    .attr('src', e.target.result);                        
            };
            reader.readAsDataURL(input.files[0]);
            $('#deleteImage').removeAttr('hidden');
        }
    }

$(function (){
  $('#deleteImage').on('click', function(){
        var gender=$("#gender").val();
        if(gender=='male'){
            $('#blah').attr('src', '/assets/img/profiles/male-user.jpg');
        }
        else{
            $('#blah').attr('src', '/assets/img/profiles/female-user.jpg');
        }
        
        $('#deleteImage').attr("hidden", true);
		$('#upload_dp').val('');
		upload_dp
        
    })
})
    function readsignURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#signature')
                    .attr('src', e.target.result);                        
            };
            reader.readAsDataURL(input.files[0]);
            $('#deleteSignature').removeAttr('hidden');
        }
    }

function uploadsignature(){
	console.log('image Upload');
	var formData = new FormData();
    formData.append("file",$('#signfile')[0].files[0]);
       
	   		$.ajax({
                    url: "{{ route('sign.upload.ajax') }}",
                    data: formData,
                    type: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    },
                    contentType: false, // NEEDED, DON'T OMIT THIS (requires jQuery 1.6+)
                    processData: false, // NEEDED, DON'T OMIT THIS
                    // ... Other options like success and etc

                    success: function (response) {
                        console.log(response);
						alert(response);

                    }
                });

}

$(function (){
  $('#deleteSignature').on('click', function(){
        $('#signature').attr('src', '');
        $('#signfile').val('');
        $('#deleteSignature').attr("hidden", true)
        
    })
})









</script>


		<div class="page-content">
			<div class="content">
			
				@if (session()->has('status'))
					<div class='alert alert-success'>
						<span class="invalid-feedback" role="alert">
							<strong >{{ session()->get('status') }}</strong>
						</span>
					</div>
					@endif
				<div class="page-title">
					<h3><i class="far fa-user-circle"></i> My Account</h3>
				</div>

				<div class="col-sm-12 col-md-12 col-lg-12">
					<ul class="nav nav-tabs" role="tablist" id="tablist">
						<li class="active">
							<a href="#basicdetails" role="tab" data-toggle="tab" aria-expanded="true"> Basic Details</a>
						</li>
						<li class="">
							<a href="#change-password" role="tab" data-toggle="tab" aria-expanded="false">Change Password</a>
						</li>

					</ul>

					<div class="tab-content">

						<div class="tab-pane active" id="basicdetails">
							<div id="user-profile" class="row">



								<div class="col-sm-12">
									<div class="grid simple">
										<div class="grid-title no-border">
											<h4><i class="far fa-address-card"></i> Basic Details</span></h4>
										</div>
										<div class="grid-body no-border">
											<br>
											<div class="row">


                                        <form action="{{ route('user.profile.saving') }}" id="form_traditional_validation" method='post' class="validate" enctype="multipart/form-data" autocomplete="off">
												@csrf
												<div class="col-sm-12 col-md-12 col-lg-2 m-b-30">
													<div class="widget-item edit-user-profile ">
														<div class="tiles">
															<div class="tiles-body no-padding">
                                                                @if($users[0]->profile_picture!=='')
                                                                    <img name='display_pic' id='blah' src="{{ asset($users[0]->profile_picture) }}" alt="">
                                                                
                                                                @else
                                                                    @if($users[0]->gender==='male')
                                                                        <img name='display_pic' id='blah' src="/assets/img/profiles/male-user.jpg" alt="">    
                                                                    @else
                                                                        <img name='display_pic' id='blah' src="/assets/img/profiles/female-user.jpg" alt="">    
                                                                    @endif                                                      
                                                                @endif
																
																<!--<img src="../assets/img/profiles/arshad-small.jpg" id='blah' alt="">-->
																<div class="overlayer bottom-right fullwidth">
																	<div class="overlayer-wrapper">
																		<div class="p-l-20 p-r-20 p-b-20 p-t-20 text-center">

																			<div class="dp-upload-icon"><i class="fa fa-camera"></i></div>
																			<input name="upload_dp" type="file" class="upload-dp" id='upload_dp' title="Upload your picture" onchange='readURL(this);' />
																			<small class="text-danger error">{{ $errors->first('upload_dp') }}</small>	
																			<div class="clearfix"></div>
																			
                                                                            <!--<input type='button' id='deleteImage' value='delete' hidden/>-->
																		</div>
																		
																	</div>
																</div>
																@if($users[0]->profile_picture!=='')
																	<a class="dp-delete-icon"><i id="deleteImage" class="far fa-trash-alt"></i></a>
																@else
																	<a class="dp-delete-icon"><i id="deleteImage" class="far fa-trash-alt" hidden></i></a>
																@endif
															</div>
														</div>
														<div class="tiles white ">
															<div class="tiles-body">
																<div class="row">
																	<div class="user-comment-wrapper pull-left">

																		<div class="comment">
																			<div class="user-name text-black semi-bold"> {{ $users[0]->displayname }}</div>
																			<div class="preview-wrapper">{{ $users[0]->designation }}</div>
																		</div>
                                                                        <?php 
																			$rolename='';
																			foreach($roleTable as $rolepkt){
																					if($rolepkt->roleid==$users[0]->role){
																						$rolename=$rolepkt->rolename;
																					}
																				} 
																				
																			?>
																		<div class="user-role"> <a href=""> {{ $rolename }} </a> </div>

																		<div class="clearfix"></div>
																	</div>

																	<div class="clearfix"></div>
																	<div class="p-l-15 p-t-10 p-r-20">
																		<p class="phone">{{ $users[0]->phone }}</p>
																		<p class="email"><a href="">{{ $users[0]->email }}</a></p>

																	</div>
																</div>
															</div>
														</div>
														
														<div class="col-sm-12">
															<div class="user-signature">
															@if($users[0]->signature != '')
																<img src="{{ asset($users[0]->signature) }}"  id='signature' alt="">
															
															@else
																<img src="../assets/img/signature/demo.jpg" id='signature' alt="">                                                     
															@endif
																
															</div>
															<input type="file" id='signfile' name='signfile' class="user-signature-upload" onchange='readsignURL(this);'>
															<small class="text-danger error">{{ $errors->first('signfile') }}</small>
															<!-- <button type="button" class="btn btn-success btn-cons" onclick='uploadsignature();'><i class="fa fa-cloud-upload-alt"></i> Upload Signature</button> -->
                                                            	
															@if($users[0]->signature != '')
																<a class="signature-delete-icon"><i id="deleteSignature" class="fa fa-times"></i></a>
															@else
																<a class="signature-delete-icon"><i id="deleteSignature" class="fa fa-times" hidden ></i></a>
															
															@endif
																
																	<!-- <a class="dp-delete-icon"><i id="deleteSignature" class="far fa-trash-alt" hidden></i></a> -->
																
															<!-- <input type='button' id='deleteSignature' value='Delete Signature' hidden/> -->
														</div>
														
													</div>
												</div>




												
													<div class="col-sm-12 col-md-12 col-lg-5 p-l-30 p-r-30">
														
														<div class="hidden">
															<div class="slide-primary">
																<input type="checkbox" name="switch" class="ios" checked="checked" />
															</div>
															<div class="slide-success">
																<input type="checkbox" name="switch" class="iosblue" checked="checked" />
															</div>
														</div>
														
														
														

														<div class="form-group">
															<label class="form-label">Full Name</label>
															<div class="controls">
                                                            <input class="form-control {{  ( $errors->first('fullname') ) ? 'error' : '' }}"  aria-invalid="false"  aria-invalid="" name="fullname" type="text" value="{{ (old('fullname'))?old('fullname'):$users[0]->fullname }}" required>
                                                                <small class="text-danger error">{{ $errors->first('fullname') }}</small>
															</div>
														</div>
														<!--<div class="form-group">
															<label class="form-label">Last Name</label>
															<div class="controls">
																<input class="form-control" name="lname" type="text" required>
															</div>
														</div>
                                                        -->
														<div class="form-group">
															<label class="form-label">Display Name</label>
															<span class="help">"Preferred name to display"</span>
															<div class="controls">
                                                            <input class="form-control {{  ( $errors->first('displayname') ) ? 'error' : '' }}"  name="displayname" type="text" value="{{ (old('displayname'))?old('displayname'):$users[0]->displayname }}" required>
                                                                <small class="text-danger error">{{ $errors->first('displayname') }}</small>
															</div>
														</div>
														<div class="form-group">
															<label class="form-label">Gender</label>
															<div class="controls">
                                                            <select name="gender" id="gender" class="select1 form-control {{  ( $errors->first('gender') ) ? 'error' : '' }}"  aria-required="true" aria-invalid="false" aria-describedby="gender-error"  required>
																	@if($users[0]->gender=='male')
																	<option  value="">Select</option>
																	<option value="male" selected>Male</option>
																	<option value="female">Female</option>
																	@else
																	<option  value="">Select</option>
																	<option value="male" >Male</option>
																	<option value="female"selected>Female</option>
																	@endif
																</select>
                                                                <small class="text-danger  error">{{ $errors->first('gender') }}</small>
															</div>
														</div>
														<div class="form-group">
															<label class="form-label">Email</label>
															<span class="help">"This is your username"</span>
															<div class="controls">
                                                                <input class="form-control {{  ( $errors->first('email') ) ? 'error' : '' }}"  name="email" type="email" value="{{ (old('email'))?old('email'):$users[0]->email }}" disabled="disabled">
                                                                <small class="text-danger error">{{ $errors->first('email') }}</small>
															</div>
														</div>
														

														<div class="form-group">
															<label class="form-label">National ID</label>
															<span class="help">"CPR number"</span>
															<div class="controls">
                                                            <input type="number" class="form-control {{  ( $errors->first('cpr') ) ? 'error' : '' }}" name='cpr' value="{{ (old('cpr'))?old('cpr'):$users[0]->cpr }}" disabled="disabled" >
                                                            
															</div>
														</div>
														
														<div class="form-group">
															<label class="form-label">National ID Expiry Date</label>
															<span class="help">"CPR Expiry Date"</span>
															<div class="controls">
                                                            @if($users[0]->cprexpiry=='1970-01-01')
                                                                <input class="form-control expdate" name="cprexpiry" type="text"   placeholder="DD-MM-YYYY" value="" required>
                                                            
                                                            @else
                                                                <input class="form-control expdate" name="cprexpiry" type="text"   placeholder="DD-MM-YYYY" value="{{ (old('cprexpiry')) ? old('cprexpiry') : date('d-m-Y',strtotime($users[0]->cprexpiry)) }}" required>
                                                            @endif
                                                            <small class="text-danger error">{{ $errors->first('crpexpiry') }}</small>
                                                        
															</div>
														</div>


														<div class="row form-row">
															<div class="col-md-6">
                                                                <label class="form-label">Mobile Number</label>
																<input class="form-control {{  ( $errors->first('phone') ) ? 'error' : '' }}"  name="phone" type="number" value="{{ (old('phone'))?old('phone'):$users[0]->phone }}" required>
                                                                <small class="text-danger error">{{ $errors->first('phone') }}</small>
															</div>
															<div class="col-md-6">
																<label class="form-label">Other Phone</label>
																<input class="form-control" name="otherphone" type="number" value="{{ (old('otherphone'))?old('otherphone'):$users[0]->otherphone }}">
                                                                <small class="text-danger error">{{ $errors->first('otherphone') }}</small>
														
                                                            </div>
														</div>

														<div class="form-group">
															<label class="form-label"><br>Date of Birth</label>
															<div class="controls">
                                                                @if($users[0]->dob=='1970-01-01')
																	<input class="form-control expdate" name="dob" type="text"   placeholder="DD-MM-YYYY" value="" >
																
																@else
																	<input class="form-control expdate" name="dob" type="text"   placeholder="DD-MM-YYYY" value="{{ (old('dob'))?old('dob'):date('d-m-Y',strtotime($users[0]->dob)) }}" >
																@endif

																<small class="text-danger error">{{ $errors->first('dob') }}</small>
					
															</div>
														</div>
														
														<div class="form-group">
															<label class="form-label">Nationality</label>
															<div class="controls">
                                                                <input class="form-control " name="nationality" type="text" value="{{ (old('nationality'))?old('nationality'):$users[0]->nationality }}" >
                                                                <small class="text-danger error">{{ $errors->first('nationality') }}</small>
															</div>
														</div>

													</div>


													<div class="col-sm-12 col-md-12 col-lg-5 p-l-30 p-r-30">


														
														<div class="form-group">
															<label class="form-label">Passport Number</label>
															<div class="controls">
                                                                <input class="form-control" name="passportnumber" type="text" value="{{ (old('passportnumber'))?old('passportnumber'):$users[0]->passportnumber }}">
																<small class="text-danger error">{{ $errors->first('passportnumber') }}</small>				
															</div>
														</div>
														<div class="form-group">
															<label class="form-label">Passport Expiry Date</label>
															<div class="controls">
                                                            @if($users[0]->passportexpiry=='1970-01-01')
																<input class="form-control expdate" name="passportexpiry" type="text"   placeholder="DD-MM-YYYY" value="" >                                                            
															@else
																<input class="form-control expdate" name="passportexpiry" type="text"   placeholder="DD-MM-YYYY" value="{{ ( !empty(old('passportexpiry')) ) ? old('passportexpiry') : date('d-m-Y',strtotime($users[0]->passportexpiry)) }}" >
															@endif
															    <small class="text-danger error">{{ $errors->first('passportexpiry') }}</small>         
															
															</div>
														</div>
														<div class="form-group">
															<label class="form-label">Driving License</label>
															<div class="controls">
                                                                <input class="form-control" name="dl" type="text"  value="{{ (old('dl'))?old('dl'):$users[0]->dl }}">
																<small class="text-danger error">{{ $errors->first('dl') }}</small>	
                                                            </div>
														</div>
														<div class="form-group">
															<label class="form-label">Driving License Expiry Date</label>
															<div class="controls">
                                                            @if($users[0]->dlexpiry=='1970-01-01')
																<input class="form-control expdate" name="dlexpiry" type="text"   placeholder="DD-MM-YYYY" value="">
                                                            
															@else
																<input class="form-control expdate" name="dlexpiry" type="text"   placeholder="DD-MM-YYYY" value="{{ ( old('dlexpiry') ) ? old('dlexpiry') : date('d-m-Y',strtotime($users[0]->dlexpiry))  }}">
															@endif


																 <small class="text-danger error">{{ $errors->first('dlexpiry') }}</small>
                                                            </div>
														</div>
														<br>
														<h4>Permanent Addess</h4>
														<div class="row form-row">
															<div class="col-md-12">
																<label class="form-label">Address</label>
																<input class="form-control" name="paddress" type="text" value="{{ (old('paddress'))?old('paddress'):$users[0]->paddress }}" required>
																<small class="text-danger error">{{ $errors->first('paddress') }}</small>				
															</div>
														</div>
														<div class="row form-row">
															<div class="col-md-6">
																<label class="form-label">City</label>
																<input class="form-control" name="pcity" type="text"  value="{{ (old('pcity'))?old('pcity'):$users[0]->pcity }}" required>
																<small class="text-danger error">{{ $errors->first('pcity') }}</small>								
															</div>
															<div class="col-md-6">
																<label class="form-label">State</label>
																<input class="form-control" name="pstate" type="text"  value="{{ (old('pstate'))?old('pstate'):$users[0]->pstate }}" required>
																<small class="text-danger error">{{ $errors->first('pstate') }}</small>								
														    </div>
														</div>
														<div class="row form-row">
															<div class="col-md-8">
																<label class="form-label">Country</label>
																<input class="form-control" name="pcountry" type="text"  value="{{ (old('pcountry'))?old('pcountry'):$users[0]->pcountry }}" required>
																<small class="text-danger error">{{ $errors->first('pcountry') }}</small>								
															 </div>
															<div class="col-md-4">
																<label class="form-label">Postal Code</label>
																<input class="form-control" name="ppost" type="number" value="{{ (old('ppost'))?old('ppost'):$users[0]->ppost }}">
																<small class="text-danger error">{{ $errors->first('ppost') }}</small>								
														   </div>
														</div>
														<div class="row form-row">
															<div class="col-md-4">
																<label class="form-label">Country Code</label>
																<input class="form-control {{  ( $errors->first('pcountrycode') ) ? 'error' : '' }}" name="pcountrycode" type="number" value="{{ (old('pcountrycode')) ?old('pcountrycode'):$users[0]->pcountrycode }}">
                                                                <small class="text-danger error">{{ $errors->first('pcountrycode') }}</small>
															</div>
															<div class="col-md-8">
																<label class="form-label">Phone Number</label>
                                                                <input class="form-control {{  ( $errors->first('pphonenumber') ) ? 'error' : '' }}" name="pphonenumber" type="number" value="{{ (old('pphonenumber'))?old('pphonenumber'):$users[0]->pphonenumber }}">
                                                                <small class="text-danger error">{{ $errors->first('pphonenumber') }}</small>
																</div>
														</div>



														<br>
														<h4>Current Addess</h4>
														<div class="row form-row">
															<div class="col-md-12">
																<label class="form-label">Address</label>
																<input class="form-control" name="caddress" type="text"  value="{{ (old('caddress'))?old('caddress'):$users[0]->caddress }}" required>
																<small class="text-danger error">{{ $errors->first('caddress') }}</small>								
														   </div>
														</div>
														<div class="row form-row">
															<div class="col-md-6">
																<label class="form-label">City</label>
																<input class="form-control" name="ccity" type="text"  value="{{ (old('ccity'))?old('ccity'):$users[0]->ccity }}" required>
																<small class="text-danger error">{{ $errors->first('ccity') }}</small>								
															 </div>
															<div class="col-md-6">
																<label class="form-label">State</label>
																<input class="form-control" name="cstate" type="text"  value="{{ (old('cstate'))?old('cstate'):$users[0]->cstate }}" required>
																<small class="text-danger error">{{ $errors->first('cstate') }}</small>								
															</div>
														</div>
														<div class="row form-row">
															<div class="col-md-8">
																<label class="form-label">Country</label>
																<input class="form-control" name="ccountry" type="text"  value="{{ (old('ccountry'))?old('ccountry'):$users[0]->ccountry }}" required>
																<small class="text-danger error">{{ $errors->first('ccountry') }}</small>				
														   </div>
															<div class="col-md-4">
																<label class="form-label">Postal Code</label>
																<input class="form-control" name="cpost" type="text" value="{{ (old('cpost'))?old('cpost'):$users[0]->cpost }}">
																<small class="text-danger error">{{ $errors->first('cpost') }}</small>								
															</div>
														</div>
														<div class="row form-row">
															<div class="col-md-4">
																<label class="form-label">Country Code</label>
																<input class="form-control {{  ( $errors->first('ccountrycode') ) ? 'error' : '' }}" name="ccountrycode" type="number" value="{{ (old('ccountrycode')) ?old('ccountrycode'):$users[0]->ccountrycode }}">
                                                                <small class="text-danger error">{{ $errors->first('pcountrycode') }}</small>
															</div>
															<div class="col-md-8">
																<label class="form-label">Phone Number</label>
                                                                <input class="form-control {{  ( $errors->first('cphonenumber') ) ? 'error' : '' }}" name="cphonenumber" type="number" value="{{ (old('cphonenumber'))?old('cphonenumber'):$users[0]->cphonenumber }}">
                                                                <small class="text-danger error">{{ $errors->first('pphonenumber') }}</small>
																</div>
														</div>							




													</div>


													<div class="col-sm-12 m-t-10 m-b-30">
														<button type="submit"  name='form1' class="btn btn-primary btn-cons pull-right"><i class="fa fa-save"></i> Save</button>
													</div>

												</form>







											</div>
										</div>
									</div>
								</div>






							</div>
						</div>
					
					
					
					<div class="tab-pane" id="change-password">
							<div class="row">
								<div class="col-sm-12">
									<div class="grid simple">
										<div class="grid-title no-border">
											<h4><i class="fa fa-wrench"></i> Change your account password</span></h4>
										</div>
										<div class="grid-body no-border">
											<br>
											<div class="row">
												

													<div class="col-sm-12 col-md-5 col-lg-5 p-l-30 p-r-30">

											 <form action="{{ route('user.profile.saving') }}" id="form_traditional_validation" method='post' class="validate" enctype="multipart/form-data">
											 @csrf	
														<div class="form-group">
															<label class="form-label">Email</label>
															<span class="help">"This is your username"</span>
															<div class="controls">
																<input class="form-control {{  ( $errors->first('email') ) ? 'error' : '' }}"  name="email" type="email" value="{{ (old('email'))?old('email'):$users[0]->email }}" disabled="disabled">
                                                                
															</div>
														</div>
														
														<div class="form-group">
															<label class="form-label">New Password</label>
															<div class="controls">
																<input class="form-control" name="password" type="password" required>
																<small class="text-danger error">{{ $errors->first('password') }}</small>
															</div>
														</div>
														
														<div class="form-group">
															<label class="form-label">Confirm Password</label>
															<div class="controls">
																<input class="form-control" name="change_password" type="password" required>
																<small class="text-danger error">{{ $errors->first('cpassword') }}</small>
															</div>
														</div>
														
														<button type="submit" name='form2' class="btn btn-primary btn-cons">Change Password</button>

													</div>

                                                </form>


											</div>
										</div>
									</div>
								</div>
							</div>
						</div>



					</div>
				</div>




			</div>
		</div>




	</div>


	

	
    @endsection
</body>
</html>