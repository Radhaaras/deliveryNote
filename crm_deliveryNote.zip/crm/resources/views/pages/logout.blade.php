<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="content-type" content="text/html;charset=UTF-8"/>
	<meta charset="utf-8"/>
	<title>QUOFLY - Enterprise Resource Planning, ERP System</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
	<meta content="" name="Enterprise Resource Planning, ERP System"/>
	<meta content="" name="AK Information Technology Bahrain"/>
	<link rel="icon" type="image/png" href="../assets/img/favicon.png"/>
	
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt" crossorigin="anonymous">
	<link href="../assets/plugins/jquery-metrojs/MetroJs.min.css" rel="stylesheet" type="text/css"/>
	<link rel="stylesheet" type="text/css" href="../assets/plugins/shape-hover/css/demo.css"/>
	<link rel="stylesheet" type="text/css" href="../assets/plugins/shape-hover/css/component.css"/>
	<link rel="stylesheet" type="text/css" href="../assets/plugins/owl-carousel/owl.carousel.css"/>
	<link rel="stylesheet" type="text/css" href="../assets/plugins/owl-carousel/owl.theme.css"/>
	<link href="../assets/plugins/pace/pace-theme-flash.css" rel="stylesheet" type="text/css" media="screen"/>
	<link href="../assets/plugins/jquery-slider/css/jquery.sidr.light.css" rel="stylesheet" type="text/css" media="screen"/>
	<link rel="stylesheet" href="../assets/plugins/jquery-ricksaw-chart/css/rickshaw.css" type="text/css" media="screen">
	<link rel="stylesheet" href="../assets/plugins/Mapplic/mapplic/mapplic.css" type="text/css" media="screen">


	<link href="../assets/plugins/pace/pace-theme-flash.css" rel="stylesheet" type="text/css" media="screen"/>
	<link href="../assets/plugins/bootstrapv3/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
	<link href="../assets/plugins/bootstrapv3/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css"/>
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<link href="../assets/plugins/animate.min.css" rel="stylesheet" type="text/css"/>
	<link href="../assets/plugins/jquery-scrollbar/jquery.scrollbar.css" rel="stylesheet" type="text/css"/>
	<link href="../quofly/css/quofly.css" rel="stylesheet" type="text/css"/>
	<!--<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">-->
</head>
<script>
/*
if (location.href.indexOf('reload')==-1)
{
   location.href=location.href+'?reload';
}
*/




</script>


<body class="error-body no-top" >
<!--
	
	<div class="container">-->
	<?php
	//print_r(Cookie::get());
	//print_r($data);
	//echo "<br>";
	$data=Cookie::get();
	//print_r($data);
	?>
	
      <div class="lockscreen-wrapper animated  flipInX">
        <div class="row ">
	
		
		 @if (session()->has('error'))
					<div class='alert alert-danger'>
						<span class="invalid-feedback" role="alert">
							<strong >{{ session()->get('error') }}</strong>
						</span>
					</div>
					@endif
		 
	      <div class="col-md-8 col-md-offset-4 col-sm-6 col-sm-offset-4 col-xs-offset-2">
		 
            <div class="profile-wrapper">
			
								@if(Cookie::get('profile_pic')!='')
						
										<img width="69" height="69" src="{{ asset(Cookie::get('profile_pic')) }}" data-src-retina="{{ asset(Cookie::get('profile_pic')) }}" data-src="{{ asset(Cookie::get('profile_pic')) }}"  alt="">
								
								@else
										
									@if(Cookie::get('gender')==='male')
											<img width="69" height="69" src="/assets/img/profiles/male-user.jpg" data-src-retina="/assets/img/profiles/male-user.jpg" data-src="/assets/img/profiles/male-user.jpg"  alt="">    
									@else
											<img width="69" height="69" src="/assets/img/profiles/female-user.jpg" data-src-retina="/assets/img/profiles/female-user.jpg" data-src="/assets/img/profiles/female-user.jpg"  alt="">    
									@endif                                                                
							
										
								@endif

              <!--<img width="69" height="69" data-src-retina="../assets/img/profiles/arshad-small.jpg" data-src="../assets/img/profiles/arshad-small.jpg" src="../assets/img/profiles/arshad-small.jpg" alt="">-->
          </div>
            <form class="user-form" id="" name="" method="POST" action="{{ route('login.submit')  }}" aria-label="{{ __('Login') }}">
							@csrf
							
							
						  <h2 class="user">{{ Cookie::get('displayname') }}</h2>
							<input type='hidden' name='email' value=" {{ Cookie::get('email')  }} " >
							<input id="login_pass" type="password" name="password" class="{{ $errors->has('password') ? ' is-invalid' : '' }}" required placeholder="Password" >
							
						  <button type="submit" class="btn btn-primary " name='logoutform' ><i class="fa fa-unlock"></i></button>
							<div><a href="{{ route('login.as.new.user') }}" name='logoutform' class="pull-left">Login as Different User</a></div>
            </form>
			
					</div>
        </div>
      </div>
      <div id="push"></div>
    </div>
	
	
	


	<script src="../assets/plugins/pace/pace.min.js" type="text/javascript"></script>
	<script src="../assets/plugins/jquery/jquery-1.11.3.min.js" type="text/javascript"></script>
	<script src="../assets/plugins/bootstrapv3/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="../assets/plugins/jquery-block-ui/jqueryblockui.min.js" type="text/javascript"></script>
	<script src="../assets/plugins/jquery-unveil/jquery.unveil.min.js" type="text/javascript"></script>
	<script src="../assets/plugins/jquery-scrollbar/jquery.scrollbar.min.js" type="text/javascript"></script>
	<script src="../assets/plugins/jquery-numberAnimate/jquery.animateNumbers.js" type="text/javascript"></script>
	<script src="../assets/plugins/jquery-validation/js/jquery.validate.min.js" type="text/javascript"></script>
	<script src="../assets/plugins/bootstrap-select2/select2.min.js" type="text/javascript"></script>
	<script src="../quofly/js/quofly.js" type="text/javascript"></script>
	<script src="../assets/js/chat.js" type="text/javascript"></script>
	<script src="../assets/plugins/jquery-ui/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
	<script src="../assets/plugins/jquery-ricksaw-chart/js/raphael-min.js"></script>
	<script src="../assets/plugins/jquery-ricksaw-chart/js/d3.v2.js"></script>
	<script src="../assets/plugins/jquery-ricksaw-chart/js/rickshaw.min.js"></script>
	<script src="../assets/plugins/jquery-sparkline/jquery-sparkline.js"></script>
	<script src="../assets/plugins/skycons/skycons.js"></script>
	<script src="../assets/plugins/owl-carousel/owl.carousel.min.js" type="text/javascript"></script>
	<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=true"></script>
	<script src="../assets/plugins/jquery-gmap/gmaps.js" type="text/javascript"></script>
	<script src="../assets/plugins/Mapplic/js/jquery.easing.js" type="text/javascript"></script>
	<script src="../assets/plugins/Mapplic/js/jquery.mousewheel.js" type="text/javascript"></script>
	<script src="../assets/plugins/Mapplic/js/hammer.js" type="text/javascript"></script>
	<script src="../assets/plugins/Mapplic/mapplic/mapplic.js" type="text/javascript"></script>
	<script src="../assets/plugins/jquery-flot/jquery.flot.js" type="text/javascript"></script>
	<script src="../assets/plugins/jquery-metrojs/MetroJs.min.js" type="text/javascript"></script>

	<script src="../assets/js/dashboard_v2.js" type="text/javascript"></script>
	
</body>
</html>