<!DOCTYPE html>

@extends('layouts.app')


@section('content')
<meta name="csrf-token" content="{{ csrf_token() }}">
<style>
@keyframes fadeIn {
 0%   { background-color: transparent; }
 50%  { background-color: #eae0ba; }
 100% { background-color: #eae0ba; }
}
@keyframes fadeOut {
 0%   { background-color: #eae0ba; }
 50%  { background-color: #eae0ba; }
 100% { background-color: transparent; }
}
.bghighli{
    background-image:none !important;
    /* -o-animation: fadeIt 7s ease-in-out;
    animation: fadeIt 7s ease-in-out;  */
 -webkit-animation: fadeIn 1s linear 0s, fadeOut 7s linear 1s;
}

</style>
<script>



function deliveryNoteSearch(){
	$.ajaxSetup({
		headers: {
			'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
		}
	});

	var searchstr=$('#dnSearch').val();
		$.ajax({
		type: 'POST',
		url: "{{ route('dn.search.ajax') }}",
		data: {'searchString' :searchstr },
		dataType: "json",
		success: function( data ) {
			//alert(data);
			//console.log(data);
			// var pkt=$.parseJSON(data);
			viewGenerator(data);
		}       
	})

}
$(function(){ // this will be called when the DOM is ready
	$.ajaxSetup({
		headers: {
			'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
		}
	});

        $('#dnSearch').keyup(function() {
			var searchstr=$('#dnSearch').val();
		 	  $.ajax({
                type: 'POST',
                url: "{{ route('dn.search.ajax') }}",
                data: {'searchString' :searchstr },
                dataType: "json",
                success: function( data ) {
					//alert(data);
					//console.log(data);
                   // var pkt=$.parseJSON(data);
                    viewGenerator(data);
                }       
            })

        });
    });
   
    function viewGenerator(data){
        $("#delnoteSearchDisplay").empty()
		var pkt = $.parseJSON(JSON.stringify(data));
		
		//console.log(pkt);
		//console.log()
		var user=pkt[0]['user'];
		var userlength=Object.keys(pkt[0]['user']).length;
		
		var deliveryNote=pkt[1]['deliveryNote'];
		//console.log(deliveryNote);
		var deliveryNotelength=Object.keys(pkt[1]['deliveryNote']).length;
		
		var invoice=pkt[2]['invoice'];
		var invoicelength=Object.keys(pkt[2]['invoice']).length;
		
		var company=pkt[4]['company'];
		var companylength=Object.keys(pkt[4]['company']).length;
		
		var client=pkt[5]['client'];
		var clientlength=Object.keys(pkt[5]['client']).length;
		
		var role=pkt[6]['role'];
		var rolelength=Object.keys(pkt[6]['role']).length;
		
		var poc=pkt[7]['poc'];
		var poclength=Object.keys(pkt[7]['poc']).length;
		
		var quotation=pkt[8]['quotation'];
		var quotationlength=Object.keys(pkt[8]['quotation']).length;

		var user_role=pkt[9]['user_role'];
		var user_rolelength=Object.keys(pkt[9]['user_role']).length;
		
		
		//console.log(quotation);
		//console.log(userlength+" "+deliveryNotelength+" "+invoicelength+" "+companylength+" "+clientlength+" "+rolelength+" "+poclength+" "+quotationlength);
		//$("#delnoteSearchDisplay").empty();
		
		var pktdump='';
		var client_details='';
		var pointofcontact='';
		var qtn_details='';
		var user_details='';
		var rolename='';
		for(var i=0;i<deliveryNotelength;i++){
			pktdump+="<div class='col-md-4 col-sm-6 col-xs-12'>";
			pktdump+="<div class='tiles white add-margin quotation-view-box'>";
			pktdump+="<div class='p-t-20 p-l-25 p-r-20 p-b-20'>";
			pktdump+="<div class='row b-grey b-b xs-p-b-20'>";
			pktdump+="<div class='col-sm-12 m-b-10'>";
			pktdump+="<div class='popover__wrapper m-b-10'>";
								
			$.each(client, function( key, value ) {
				//console.log(deliveryNote[0].clientno+" "+value.client_id);
				if(parseInt(deliveryNote[0].clientno)==parseInt(value.client_id)){
					client_details = value;
					return;
				}						
			});
			$.each(poc, function( key, value ) {
				if(parseInt(value.client_id)==parseInt(client_details.client_id)){
					pointofcontact = value;
					return;
				}						
			});
			$.each(quotation, function( key, value ) {
				if(parseInt(value.client_id)==parseInt(client_details.client_id)){
					qtn_details = value;
					return;
				}						
				
			});
			
			pktdump+="<a href='#'><h3 class='no-margin'>"+client_details.name+"</h3></a>";
			pktdump+="<div class='col-sm-12 col-lg-8 col-xs-12'>";
			pktdump+="	<div class='push popover__content'>";
			pktdump+="		<div class='row'>";
			pktdump+="			<div class='col-sm-12 col-md-12 col-lg-12 no-padding'>";
			pktdump+="				<div class='tile-more-content no-padding company-tiles'>";
			pktdump+="					<a href='edit-client-profile.php'>";
			pktdump+="						<div class='tiles green overflow-hidden full-height client-logo '>";
			pktdump+="							<div class='overlayer bottom-right fullwidth'>";
			pktdump+="								<div class='overlayer-wrapper'>";
			pktdump+="									<div class='tiles gradient-title p-l-20 p-r-20 p-b-20 p-t-20'>";
			pktdump+="										<div class='pull-left'>";
			pktdump+="											<div class='company-title'>"+client_details.name+"</div>";
			pktdump+="										</div>";
			pktdump+="										<div class='clearfix'></div>";
			pktdump+="									</div>";
			pktdump+="								</div>";
			pktdump+="							</div>";
			pktdump+="							<img src='../assets/img/clients/client-default.jpg' alt='' class='lazy hover-effect-img'>";
			pktdump+="						</div>";
			pktdump+="					</a>";
			pktdump+="					<div class='tiles-body'>";
			pktdump+="						<ul class='progress-list'>";
			pktdump+="							<li class='p-b-80'>";
			pktdump+="								<div class='details-wrapper'>";
			pktdump+="									<div class='name'>Contact</div>";
			pktdump+="									<div class='description'>"+ client_details.contact+"</div>";
			pktdump+="									<div class='description'>"+ client_details.email+"</div>";
			pktdump+="								</div>";

			pktdump+="							</li>";
			pktdump+="							<li class='p-b-80'>";
			pktdump+="								<div class='details-wrapper'>";
			pktdump+="									<div class='name'>Contact Person</div>";
			pktdump+="									<div class='description'>"+ pointofcontact.name +"</div>";
			pktdump+="									<div class='description'>"+ pointofcontact.contact +"</div>";
			pktdump+="									<div class='description'>"+ pointofcontact.email +"</div>";
			pktdump+="								</div>";

			pktdump+="							</li>";

			pktdump+="							<li class='p-t-20'>";
			pktdump+="								<div class='details-wrapper'>";
			pktdump+="									<div class='name'>Quotations Sent</div>";
			pktdump+="								</div>";
			pktdump+="								<div class='details-status pull-right'> "+qtn_details.client_count+"</div>";
			pktdump+="								<div class='clearfix'></div>";

			pktdump+="							</li>";
			pktdump+="						</ul>";
			pktdump+="					</div>";
			pktdump+="				</div>";
			pktdump+="			</div>";
			pktdump+="		</div>";
			pktdump+="	</div>";
			pktdump+="</div>";
					
			pktdump+="</div>";

			pktdump+="</div>";
                                
                                


            pktdump+="<div class='col-sm-12'>";
                                    
            pktdump+="                        <div class=''>";
            pktdump+="   <p class='text-grey'>Delivery Number: #<span class='text-black'> "+ deliveryNote[i].deliverynotecode +" </span></p>";
            pktdump+="                        </div>";
            pktdump+="                        <div class=''>";
            pktdump+="           <p class='text-grey'>Delivery Date: <span class='text-black'> "+ deliveryNote[i].delivery_date +" </span></p>";
			pktdump+="                       </div>";
            pktdump+="                        <div class=''>";
            pktdump+="                    <p class='text-grey'>Invoice Number: <span class='text-info'> "+ deliveryNote[i].invoiceno +"</span></p>";
            pktdump+="                        </div>";
            pktdump+="                        <div class=''>";
            pktdump+="                    <p class='text-grey'>Project ID: #<span class='text-info'> "+ deliveryNote[i].projectno +" </span></p>";
			pktdump+="                        </div>";
                                    
            pktdump+="                    </div>";
                                

            pktdump+="                </div>";
            pktdump+="                <div class='row b-grey'>";
                                
							$.each(user, function( key, users ) {
									//console.log(deliveryNote[0].clientno+" "+value.client_id);
								if(parseInt(deliveryNote[i].created_by)==parseInt(users.id)){
									user_details = users;
									return;
								}						
							});	
                                
                                
			pktdump+="                    <div class='col-sm-6 col-xs-6 '>";
			pktdump+="                <div class='m-t-10'>";
			pktdump+="                    <div class='text-grey'> Created By: </div>";
			pktdump+="                    <div class='clearfix'></div>";
			pktdump+="                    <div class='popover__wrapper m-t-5'>";
			pktdump+="                        <a>"+ user_details.displayname +"</a>";
			pktdump+="                        <div class='push popover__content'>";

            pktdump+="                            <div class='row'>";
			pktdump+="                                <div class='col-sm-12 col-md-12 col-lg-12 no-padding'>";
			pktdump+="                                    <div class='widget-item user '>";
			pktdump+="                                        <div class='tiles user-dp'>";
			pktdump+="                                            <div class='tiles-body no-padding'>";
                                                                if(user_details.profile_picture!=''){
			pktdump+="                                                <img src='{{ asset("+user_details.profile_picture+") }}' alt=''>";
                                                                }
																else{
                                                                   if(user_details.gender==='male'){
			pktdump+="                                                    <img src='/assets/img/profiles/male-user.jpg' alt=''>";    
																	}
																	else{
			pktdump+="                                                    <img src='/assets/img/profiles/female-user.jpg' alt=''>";    
																	}                                                                                 
																}
                                                                   
			pktdump+="                                                        <div class='overlayer bottom-right fullwidth'>";
            pktdump+="                                                            <div class='overlayer-wrapper'>";
			pktdump+="                                                        <div class=' p-l-20 p-r-20 p-b-20 p-t-20'>";
													$.each(role, function( key, roles ) {
														if(parseInt(roles.roleid)==parseInt(user_details.role)){
															rolename = roles.rolename;
															return;
														}						
													});	
			pktdump+="                                     <div class='text-center'> <a class='hashtags'> "+rolename+" </a> </div>";
			pktdump+="                                                            <div class='clearfix'></div>";
			pktdump+="                                                        </div>";
			pktdump+="                                                    </div>";
			pktdump+="                                                </div>";
			pktdump+="                                                <br>";
			pktdump+="                                            </div>";
			pktdump+="                                        </div>";
			pktdump+="                                        <div class='tiles white '>";
			pktdump+="                                            <div class='tiles-body'>";
			pktdump+="                                                <div class='row'>";
			pktdump+="                                                    <div class='user-comment-wrapper pull-left'>";

			pktdump+="                                                        <div class='comment'>";
			pktdump+="                                                  <div class='user-name text-black semi-bold'>"+user_details.fullname+" </div>";
			pktdump+="                                                  <div class='preview-wrapper'> "+user_details.designation +"</div>";
			pktdump+="                                                        </div>";
			pktdump+="                                                        <div class='clearfix'></div>";
			pktdump+="                                                    </div>";

            pktdump+="                                                    <div class='clearfix'></div>";
			pktdump+="                                                    <div class='p-l-15 p-r-20 popover__message'>";
			pktdump+="                                                        <p> "+user_details.phone+" </p>";
			pktdump+="                                                        <p> "+user_details.email+" </p>";
			
			pktdump+="                                                  </div>";
            pktdump+="                                                        </div>";
            pktdump+="                                                    </div>";
            pktdump+="                                                </div>";
            pktdump+="                                            </div>";
            pktdump+="                                        </div>";
            pktdump+="                                    </div>";

            pktdump+="                                </div>";
            pktdump+="                            </div>";

            pktdump+="                        </div>";
            pktdump+="                    </div>";
            pktdump+="                    <div class='col-sm-6 col-xs-6 text-right'>";
            pktdump+="                    <div class='m-t-10'>";
                  console.log(user_role);              
								if(parseInt(user_role.edit)==1 || parseInt(user_role.role)==1){
			pktdump+="<div class='view-btn'><a href='{{route('edit.deliveryNote','')}}/"+deliveryNote[i].id+"' class='btn button'>Edit</a></div>";
								}else{
			pktdump+="<div class='view-btn'><a href='{{route('readonly.deliveryNote','')}}/"+deliveryNote[i].id+"' class='btn button'>View</a></div>";
                                }
            pktdump+="</div></div></div></div></div></div>";
		}//forloop
        $('#delnoteSearchDisplay').append(pktdump);
    }
</script>

		<div class="page-content">
			<div class="content">
				@if (session()->has('success'))
					<div class='alert alert-success'>
							<span class="invalid-feedback" role="alert">
									<strong >{{ session()->get('success') }}</strong>
							</span>
					</div> 
                    
					@endif
					
				<div class="page-title">
					<h3><i class="fa fa-file-signature"></i>View Delivery Notes</h3>
				</div>

				<div class="row projects-topsec">

					<div class="col-sm-12">

						<div class="col-sm-12 col-md-8 search-column">
							<input name="" type="text" class="project-search" id='dnSearch' placeholder="Type here to search...">
							<button type="button" class="btn btn-search btn-cons" onclick='deliveryNoteSearch()'><i class="fa fa-search"></i></button>
						</div>



						<div class="col-sm-12 col-md-4 proj-top-right">

							

							<div class="btn-group pull-right">
								<a href="#" data-toggle="dropdown" class="btn dropdown-toggle btn-demo-space filter"> <span class="anim150">Sort by</span> <span class="caret"></span> </a>
								<ul class="dropdown-menu">
									<li class="active" data-filter="all" data-dimension="recreation" ><a href="{{ route('sort.delivery.note.ajax', 1) }}">All</a>
									</li>
									<li data-filter="camping" data-dimension="recreation"  ><a href="{{ route('sort.delivery.note.ajax', 2) }}" >Date</a>
									</li>
									<li data-filter="climbing" data-dimension="recreation"  ><a href="{{ route('sort.delivery.note.ajax', 3) }}" >Oldest First</a>
									</li>
									<li data-filter="fishing" data-dimension="recreation"  ><a href="{{ route('sort.delivery.note.ajax', 4 ) }}">Newest First</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
				<div id="delivery-view" class="row">
					<div class="row m-b-20 tiles-container quotation-view delivery-view">
					<div id='delnoteSearchDisplay'>
						@foreach($deliveryNote as $delnote)
							
							
						
							<div class="col-md-4 col-sm-6 col-xs-12 ">
							<div class="tiles white add-margin quotation-view-box">
							@if(($maxid > 0) && ($maxid==$delnote->deliverynoteno))
									<div class="p-t-20 p-l-25 p-r-20 p-b-20  bghighli">
							@else
									<div class="p-t-20 p-l-25 p-r-20 p-b-20 ">
							@endif
								
									<div class="row b-grey b-b xs-p-b-20">
										<div class="col-sm-12 m-b-10">
											<div class="popover__wrapper m-b-10">
												<?php 
												$client_details='';
												$pointofcontact='';
												$qtn_details='';
													foreach ($client as $clients){
														if($delnote->clientno==$clients->client_id){
															$client_details = $clients;
															break;
														}
													}
													foreach($poc as $pocs){
														if($pocs->client_id==$clients->client_id){
															$pointofcontact=$pocs;
															break;
														}
													}
													foreach($quotation as $quotations){
														if($quotations->client_id==$clients->client_id){
															$qtn_details=$quotations;
															break;
														}
													}
													
													
												?>

												<a href="#"><h3 class="no-margin">{{ $client_details->name }}</h3></a>
												<div class="col-sm-12 col-lg-8 col-xs-12">
													<div class="push popover__content">
														<div class="row">
															<div class="col-sm-12 col-md-12 col-lg-12 no-padding">
																<div class="tile-more-content no-padding company-tiles">
																	<a href="edit-client-profile.php">
																		<div class="tiles green overflow-hidden full-height client-logo ">
																			<div class="overlayer bottom-right fullwidth">
																				<div class="overlayer-wrapper">
																					<div class="tiles gradient-title p-l-20 p-r-20 p-b-20 p-t-20">
																						<div class="pull-left">
																							<div class="company-title">{{ $client_details->name }}</div>
																						</div>
																						<div class="clearfix"></div>
																					</div>
																				</div>
																			</div>
																			<img src="../assets/img/clients/client-default.jpg" alt="" class="lazy hover-effect-img">
																		</div>
																	</a>
																	<div class="tiles-body">
																		<ul class="progress-list">
																			<li class="p-b-80">
																				<div class="details-wrapper">
																					<div class="name">Contact</div>
																					<div class="description">{{ $client_details->contact }}</div>
																					<div class="description">{{ $client_details->email }}</div>
																				</div>

																			</li>
																			<li class="p-b-80">
																				<div class="details-wrapper">
																					<div class="name">Contact Person</div>
																					<div class="description">{{ $pointofcontact->name }}</div>
																					<div class="description">{{ $pointofcontact->contact }}</div>
																					<div class="description">{{ $pointofcontact->email }}</div>
																				</div>

																			</li>

																			<li class="p-t-20">
																				<div class="details-wrapper">
																					<div class="name">Quotations Sent</div>
																				</div>
																				<div class="details-status pull-right"> {{ $qtn_details->client_count }}</div>
																				<div class="clearfix"></div>

																			</li>
																		</ul>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
												
											</div>

										</div>
										
										


										<div class="col-sm-12">
											
											<div class="">
												<p class="text-grey">Delivery Number: #<span class="text-black"> {{ $delnote->deliverynotecode }} </span></p>
											</div>
											<div class="">
												<p class="text-grey">Delivery Date: <span class="text-black"> {{ $delnote->delivery_date }} </span></p>
											</div>
											<div class="">
												<p class="text-grey">Invoice Number: <span class="text-info"> {{ $delnote->invoiceno }} </span></p>
											</div>
											<div class="">
												<p class="text-grey">Project ID: #<span class="text-info"> {{ $delnote->projectno }} </span></p>
											</div>
											
										</div>
										

									</div>
									<div class="row b-grey">
										
										<?php
											$user_details='';$rolename='';
											foreach($user as $users){
												if($delnote->created_by==$users->id){
													$user_details=$users;		
													break;
												}
											}
										

										?>
										
										
										<div class="col-sm-6 col-xs-6 ">
											<div class="m-t-10">
												<div class="text-grey"> Created By: </div>
												<div class="clearfix"></div>
												<div class="popover__wrapper m-t-5">
													<a>{{ $user_details->displayname }}</a>
													<div class="push popover__content">

														<div class="row">
															<div class="col-sm-12 col-md-12 col-lg-12 no-padding">
																<div class="widget-item user ">
																	<div class="tiles user-dp">
																		<div class="tiles-body no-padding">
																		@if($user_details->profile_picture!='')
																			<img src="{{ asset($data->profile_picture) }}" alt="">
																			
																		@else
																			@if($user_details->gender!='')
																				@if($user_details->gender==='male')
																					<img src="/assets/img/profiles/male-user.jpg" alt="">    
																				@else
																					<img src="/assets/img/profiles/female-user.jpg" alt="">    
																				@endif                                                                
																			@else
																				<img src="/assets/img/profiles/user.jpg" alt="">                                                                          
																			@endif                                                             
																		@endif
																			<!--<img src="../assets/img/profiles/arshad-small.jpg" alt="">-->
																			<div class="overlayer bottom-right fullwidth">
																				<div class="overlayer-wrapper">
																					<div class=" p-l-20 p-r-20 p-b-20 p-t-20">
																						<?php
																						foreach($role as $roles){
																							if($roles->roleid==$user_details->role){
																								$rolename=$roles->rolename;
																							}
																						}
																						?>
																						<div class="text-center"> <a class="hashtags"> {{ $rolename }} </a> </div>
																						<div class="clearfix"></div>
																					</div>
																				</div>
																			</div>
																			<br>
																		</div>
																	</div>
																	<div class="tiles white ">
																		<div class="tiles-body">
																			<div class="row">
																				<div class="user-comment-wrapper pull-left">

																					<div class="comment">
																						<div class="user-name text-black semi-bold">{{ $user_details->fullname }}</div>
																						<div class="preview-wrapper">{{ $user_details->designation }}</div>
																					</div>
																					<div class="clearfix"></div>
																				</div>

																				<div class="clearfix"></div>
																				<div class="p-l-15 p-r-20 popover__message">
																					<p>{{ $user_details->phone }}</p>
																					<p>{{ $user_details->email }}</p>

																				</div>
																			</div>
																		</div>
																	</div>
																</div>
															</div>
														</div>

													</div>
												</div>

											</div>
										</div>
										<div class="col-sm-6 col-xs-6 text-right">
										<div class="m-t-10">
										<?php
											foreach($logedInuser as $logger){
												if($logger->menuid==6){
													$loged_user=$logger;
													break;
												}
											}
										//	print_r($loged_user);
											if($loged_user->edit==1 || $loged_user->role==1){
												?>
												
													<div class="view-btn"><a href="{{ route('edit.deliveryNote', $delnote->id ) }}" class="btn button">Edit</a></div>
													
											<?php
												}else{
											?>
													<div class="view-btn"><a href="{{ route('readonly.deliveryNote', $delnote->id ) }}" class="btn button">View</a></div>
											<?php
												}
											?>
											
											</div>
										</div>


									</div>
								</div>

							</div>
						</div>
					
					@endforeach
					</div>
					</div>
				</div>
			</div>
		</div>
	</div>

<!--


	<div id="delivery-view" class="row">
					<div class="row m-b-20 tiles-container quotation-view delivery-view">
						<div class="col-md-4 col-sm-6 col-xs-12">
							<div class="tiles white add-margin quotation-view-box">
								
								<div class="p-t-20 p-l-25 p-r-20 p-b-20">
									<div class="row b-grey b-b xs-p-b-20">
										<div class="col-sm-12 m-b-10">
											<div class="popover__wrapper m-b-10">
												<a href="#"><h3 class="no-margin">Company Name</h3></a>
												<div class="col-sm-12 col-lg-8 col-xs-12">
													<div class="push popover__content">
														<div class="row">
															<div class="col-sm-12 col-md-12 col-lg-12 no-padding">
																<div class="tile-more-content no-padding company-tiles">
																	<a href="edit-client-profile.php">
																		<div class="tiles green overflow-hidden full-height client-logo ">
																			<div class="overlayer bottom-right fullwidth">
																				<div class="overlayer-wrapper">
																					<div class="tiles gradient-title p-l-20 p-r-20 p-b-20 p-t-20">
																						<div class="pull-left">
																							<div class="company-title">Company Name</div>
																						</div>
																						<div class="clearfix"></div>
																					</div>
																				</div>
																			</div>
																			<img src="../assets/img/clients/client-default.jpg" alt="" class="lazy hover-effect-img">
																		</div>
																	</a>
																	<div class="tiles-body">
																		<ul class="progress-list">
																			<li class="p-b-80">
																				<div class="details-wrapper">
																					<div class="name">Contact</div>
																					<div class="description">+973 1234 5678</div>
																					<div class="description">info@company.com</div>
																				</div>

																			</li>
																			<li class="p-b-80">
																				<div class="details-wrapper">
																					<div class="name">Contact Person</div>
																					<div class="description">Name</div>
																					<div class="description">+973 1234 5678</div>
																					<div class="description">info@company.com</div>
																				</div>

																			</li>

																			<li class="p-t-20">
																				<div class="details-wrapper">
																					<div class="name">Quotations Sent</div>
																				</div>
																				<div class="details-status pull-right"> 20</div>
																				<div class="clearfix"></div>

																			</li>
																		</ul>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>

										</div>
										
										


										<div class="col-sm-12">
											
											<div class="">
												<p class="text-grey">Invoice Number: #<span class="text-info">0001</span></p>
											</div>
											<div class="">
												<p class="text-grey">Delivery Date: <span class="text-black">12 Aug 2018</span></p>
											</div>
											<div class="">
												<p class="text-grey">Project ID: #<span class="text-info">0001</span></p>
											</div>
											
										</div>
										

									</div>
									<div class="row b-grey">
										
										
										
										
										<div class="col-sm-6 col-xs-6 ">
											<div class="m-t-10">
												<div class="text-grey"> Created By: </div>
												<div class="clearfix"></div>
												<div class="popover__wrapper m-t-5">
													<a>Arshad</a>
													<div class="push popover__content">

														<div class="row">
															<div class="col-sm-12 col-md-12 col-lg-12 no-padding">
																<div class="widget-item user ">
																	<div class="tiles user-dp">
																		<div class="tiles-body no-padding">
																			<img src="../assets/img/profiles/arshad-small.jpg" alt="">
																			<div class="overlayer bottom-right fullwidth">
																				<div class="overlayer-wrapper">
																					<div class=" p-l-20 p-r-20 p-b-20 p-t-20">
																						<div class="text-center"> <a class="hashtags"> Administrator </a> </div>
																						<div class="clearfix"></div>
																					</div>
																				</div>
																			</div>
																			<br>
																		</div>
																	</div>
																	<div class="tiles white ">
																		<div class="tiles-body">
																			<div class="row">
																				<div class="user-comment-wrapper pull-left">

																					<div class="comment">
																						<div class="user-name text-black semi-bold">Full Name </div>
																						<div class="preview-wrapper">Designer</div>
																					</div>
																					<div class="clearfix"></div>
																				</div>

																				<div class="clearfix"></div>
																				<div class="p-l-15 p-r-20 popover__message">
																					<p>+973 3397 4241</p>
																					<p>arshad@akit.me</p>

																				</div>
																			</div>
																		</div>
																	</div>
																</div>
															</div>
														</div>

													</div>
												</div>

											</div>
										</div>
										<div class="col-sm-6 col-xs-6 text-right">
											<div class="m-t-10">
												<div class="view-btn"><a href="create-delivery-note.php" class="btn button">View</a></div>
											</div>
										</div>


									</div>
								</div>

							</div>
						</div>
					</div>
				</div>
			</div>
	<script src="../assets/plugins/pace/pace.min.js" type="text/javascript"></script>
	<script src="../assets/plugins/jquery/jquery-1.11.3.min.js" type="text/javascript"></script>
	<script src="../assets/plugins/bootstrapv3/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="../assets/plugins/jquery-block-ui/jqueryblockui.min.js" type="text/javascript"></script>
	<script src="../assets/plugins/jquery-unveil/jquery.unveil.min.js" type="text/javascript"></script>
	<script src="../assets/plugins/jquery-scrollbar/jquery.scrollbar.min.js" type="text/javascript"></script>
	<script src="../assets/plugins/jquery-numberAnimate/jquery.animateNumbers.js" type="text/javascript"></script>
	<script src="../assets/plugins/jquery-validation/js/jquery.validate.min.js" type="text/javascript"></script>
	<script src="../quofly/js/quofly.js" type="text/javascript"></script>
	<script src="../assets/plugins/jquery-ui/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
	<script src="../assets/plugins/jquery-flot/jquery.flot.js" type="text/javascript"></script>
-->
@endsection