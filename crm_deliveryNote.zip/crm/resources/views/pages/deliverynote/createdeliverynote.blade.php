<!DOCTYPE html>

@extends('layouts.app')


@section('content')
<script>
$(document).ready(function() {

	$(".deleterow").click(function(){
		var rowcount=$('#rowcount tr').length;
		if (rowcount > 1) {
			$(this).parents('tr').remove();
			var rowcountAfterDelete = document.getElementById("rowcount").rows.length;  
			//alert(rowcountAfterDelete);
			i=1;
			$('#rowcount tr').each(function (i) {
				$(this).find('span').text(i+1);
			});
		} else {
			var pkt="<div class='alert alert-warning'><span class='invalid-feedback' role='alert'><strong > You cannot delete all rows! </strong></span></div>";
			//alert('pkt');
			$('#msgdisp').html(pkt);
			jQuery('html,body').animate({scrollTop:0},200);
		}
		
	});
});


</script>

		<div class="page-content">
			<div class="content">
			<div id='msgdisp'></div>
				<div class="page-title">
					<h3 class="m-l-15"><i class="fa fa-file-signature">+</i>Delivery Note</h3>
				</div>
				
				<div class="row-fluid select2-display-none">
					<div class="slide-primary">
						<input type="checkbox" name="switch" class="ios" checked="checked"/>
					</div>
					<div class="slide-success">
						<input type="checkbox" name="switch" class="iosblue" checked="checked"/>
					</div>
				</div>
				<?php 

					//print_r($invoice);
					//print_r($invoice_content);
					//print_r($company);
					//print_r($client);
					//print_r(Auth::user());
					

				?>
			<form action="{{ route('delivery.note.save') }}" autocomplete="off" method='post' id='createdn' class="validate" enctype="multipart/form-data" >	
												{{ csrf_field() }}
				<div class="row">
					<div class="col-md-11" id="print-deliverynote">
						<div class="grid simple">
							<div class="grid-body no-border invoice-body boredr-radius-5">
								<br>
								<div class="pull-left"><img src="../assets/img/logo/logo.svg" class="invoice-logo" alt=""><br>
									<address>
									{{ ucwords($company[0]->companyname) }} <br>
									{{ $company[0]->flat}} ,&nbsp;{{ $company[0]->building}},&nbsp;{{ $company[0]->road}}<br>
									{{ $company[0]->block}},&nbsp;{{ ucwords($company[0]->avenue) }}<br>
									{{ ucwords($company[0]->city) }} ,&nbsp;{{ ucwords($company[0]->state) }}<br>
									{{ ucwords($company[0]->country) }}<br>
									{{ $company[0]->p_telephone }}<br> 
									  
									</address>
								
								</div>
								<div class="pull-right invoice-title">
									<h2>Delivery Note</h2>
								</div>
								<div class="clearfix"></div>
								<br>
								<br>
								<div class="row">
									<div class="col-md-9">
										<h4 class="semi-bold">{{ $client[0]->name }}</h4>
										<address>
										@if($client[0]->address!='')
											{{ $client[0]->address }} <br>
										@endif
										{{ ucwords($client[0]->city) }} ,&nbsp;{{ ucwords($client[0]->state) }}<br>
										{{ ucwords($client[0]->country) }}<br>
										{{ $client[0]->contact }}<br> 
										</address>
									
									</div>
									<div class="col-md-3">
										<br>
										<div>
											<div class="pull-left"> INVOICE NO : </div>
											<div class="pull-right"> {{ $invoice[0]->invoice_code }} </div>
											<input type='hidden'  name='invoiceno' value='{{ $invoice[0]->invoice_code }}' />
											<input type='hidden'  name='clientno' value='{{ $invoice[0]->client_id }}' />
											<div class="clearfix"></div>
										</div>
										<div>
											<div class="pull-left"> CREATED ON : </div>
											<div class="pull-right"> {{ date('d-m-Y') }} </div>
											<div class="clearfix"></div>
										</div>
										<div>
											<div class="pull-left"> CREATED BY : </div>
											<div class="pull-right">
												<div class="popover__wrapper">
															<a>{{ Auth::user()->displayname }}</a>
															<div class="push popover__content">

																<div class="row">
																	<div class="col-sm-12 col-md-12 col-lg-12 no-padding">
																		<div class="widget-item user ">
																			<div class="tiles user-dp">
																				<div class="tiles-body no-padding">
																				@if(Auth::user()->profile_picture!='')
																				<img src="{{ asset($data->profile_picture) }}" alt="">
																				
																			@else
																				@if(Auth::user()->gender!='')
																					@if(Auth::user()->gender==='male')
																						<img src="/assets/img/profiles/male-user.jpg" alt="">    
																					@else
																						<img src="/assets/img/profiles/female-user.jpg" alt="">    
																					@endif                                                                
																				@else
																					<img src="/assets/img/profiles/user.jpg" alt="">                                                                          
																				@endif                                                             
																			@endif
																	
																					<div class="overlayer bottom-right fullwidth">
																						<div class="overlayer-wrapper">
																							<div class=" p-l-20 p-r-20 p-b-20 p-t-20">
																							<?php 
																								$rolename='';
																								foreach($role as $rolepkt){
																										if($rolepkt->roleid==Auth::user()->role){
																											$rolename=$rolepkt->rolename;
																										}
																									} 
																								?>
																								@if(Auth::user()->role!='')
																									<div class="text-center"> <a class="hashtags"> {{ $rolename }} </a> </div>
																								@else
																									<div class="text-center"> <a class="hashtags"> No Role Assigned </a> </div>
																								@endif
																								<div class="clearfix"></div>
																							</div>
																						</div>
																					</div>
																					<br>
																				</div>
																			</div>
																			<div class="tiles white ">
																				<div class="tiles-body">
																					<div class="row">
																						<div class="user-comment-wrapper text-left">

																							<div class="comment">
																								<div class="user-name text-black semi-bold"> {{ Auth::user()->fullname }} </div>
																								<div class="preview-wrapper">{{ Auth::user()->designation }}</div>
																							</div>
																							<div class="clearfix"></div>
																						</div>

																						<div class="clearfix"></div>
																						<div class="p-l-15 p-r-20 popover__message">
																							<p>{{ Auth::user()->phone }}</p>
																							<p>{{ Auth::user()->email }}</p>

																						</div>
																					</div>
																				</div>
																			</div>
																		</div>
																	</div>
																</div>

															</div>
														</div>
											</div>
											<div class="clearfix"></div>
										</div>
										<div>
											<div class="pull-left"> PROJECT REFERENCE : </div>
											<div class="pull-right"> <a> {{ $invoice[0]->project_id }} </a> </div>
											<input type='hidden'  name='projectno' value='{{ $invoice[0]->project_id }}' />
											<div class="clearfix"></div>
										</div>
										<div>
											<div class="pull-left"> DELIVERY DATE : </div>
											<div class="pull-right"> <input type='text' name='delivery_date'  class="jquerydate" placeholder="DD-MM-YYYY" required /> </div>
											<div class="clearfix"></div>
										</div>	
										
									</div>
								</div>
								<br><br><br>
								
								<table class="table no-more-tables invoice-edit-table">
									<thead>
									  <tr>
										<th style="width:2%">SL NO.</th>
										<th style="width:22%">Description</th>
										<th class="number" style="width:2%">QUANTITY</th>
										<th style="width:1%"></th>
									  </tr>
									</thead>
									<tbody id='rowcount'>
									<?php $i=0; ?>
									@foreach ($invoice_content as $content)
									  <tr>
										<td class=""><span>{{ ++$i }}</span></td>
										<td class=""><textarea rows="1" cols="100" required class="full-width" name='description{{$i}}' >{{ $content->description }}</textarea></td>
										<td class="number"><input type="number" class="form-group price-input" name='quantity{{$i}}' value='{{ $content->quantity }}' required></td>
										<td class="text-center"><a ><i class="fa fa-minus-circle text-danger deleterow"  ></i></a></td>
									  </tr>
									@endforeach	
										
									  
									</tbody>
								  </table>
								<div class="row">
									<div class="pull-right m-t-30">
										<div class="col-sm-12">
									<div class="p-t-20 text-right pull-right m-r-35">
										<div class="text-right pull-left m-r-10"><button class="btn btn-estimate-save" name='form1' >Save</button>
										</div>
										<div class="text-right pull-left"><button class="btn btn-create-save" name='form2' >Save &amp; Print</button>
										</div>
									</div>
								</div>
									</div>
								</div>
							</div>
						</div>
						</form>
						
						
						
						
						
					</div>
					<div class="col-md-1">
						<div class="invoice-button-action-set">
							<p>
								<button class="btn" type="button" onclick="printDiv('print-deliverynote'); return false;"><i class="fa fa-print"></i></button>
							</p>
							<p>
								<button class="btn" type="button"><i class="far fa-file-pdf"></i></button>
							</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>


@endsection
