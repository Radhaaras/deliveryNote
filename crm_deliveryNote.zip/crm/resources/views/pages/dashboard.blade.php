@extends('layouts.app')
<?php
//print_r(session()->all());
?>
@section('content')
<script>
window.addEventListener("beforeunload", function (e) {        
    $.ajax({
        type: "POST",
        url: logout_url_here,        
    });
    return;
});
</script>
<div class="page-content">
    <div class="content">
        <div class="page-title">
            <h3>Dashboard</h3>
            <div>
            <?php
                    $cookies = Cookie::get();	
                    //print_r($cookies);
					echo url()->current();
					?>
            </div>
        </div>
    </div>
</div>
		
@endsection


