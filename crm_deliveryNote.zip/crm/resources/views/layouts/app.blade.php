<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8"/>
	<meta charset="utf-8"/>
	<title>QUOFLY - Enterprise Resource Planning, ERP System</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
	<meta content="" name="Enterprise Resource Planning, ERP System"/>
	<meta content="" name="AK Information Technology Bahrain"/>
	<link rel="icon" type="image/png" href="../assets/img/favicon.png"/>

	
    @include('includes.header.header')
    @include('includes.header.top-header')
    
 <body>       
        <div class="page-container row-fluid">
            @include('includes.sidebar.sidebar')
            <a href="#" class="scrollup">Scroll</a>
            <div class="footer-widget">
                Powered by <a href="http://www.quofly.com" target="_blank">QUOFLY</a>
            </div>
            @yield('content')
        </div>
    @include('includes.footer.footer')