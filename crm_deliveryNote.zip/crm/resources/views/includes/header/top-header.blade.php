
<div class="header navbar navbar-inverse ">

	<div class="navbar-inner">
		<div class="header-seperation">
			<ul class="nav pull-left notifcation-center visible-xs visible-sm">
				<li class="dropdown">
					<a href="#main-menu" data-webarch="toggle-left-side">
						<i class="material-icons">menu</i>
					</a>

				</li>
			</ul>

			<a href=''>
				<img src="../assets/img/logo.svg" class="logo" alt="" />
			</a>
		</div>

		<div class="header-quick-nav">

			<div class="pull-left">
				<ul class="nav quick-section">
					<li class="quicklinks">
					<a href="#" class="" id="layout-condensed-toggle">
					<i class="material-icons">menu</i>
					</a>

					</li>
				</ul>

				<ul class="nav quick-section">

					<li class="quicklinks">
						<a href="#" class="" id="my-task-list" data-placement="bottom" data-content='' data-toggle="dropdown" data-original-title="Notifications">
							<i class="material-icons">notifications</i>
							<span class="badge badge-important bubble-only"></span>
						</a>
					</li>

				</ul>
			</div>

			<div id="notification-list" style="display:none">
				<div style="width:300px">
					<div class="notification-messages info">
						<div class="iconholder">
							<i class="icon-warning-sign"></i>
						</div>
						<div class="message-wrapper">
							<div class="heading">
								Server load limited
							</div>
							<div class="description">
								Database server has reached its daily capicity
							</div>
							<div class="date pull-left">
								2 mins ago
							</div>
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="notification-messages info">
						<div class="iconholder">
							<i class="icon-warning-sign"></i>
						</div>
						<div class="message-wrapper">
							<div class="heading">
								Server load limited
							</div>
							<div class="description">
								Database server has reached its daily capicity
							</div>
							<div class="date pull-left">
								2 mins ago
							</div>
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="notification-messages info">
						<div class="iconholder">
							<i class="icon-warning-sign"></i>
						</div>
						<div class="message-wrapper">
							<div class="heading">
								Server load limited
							</div>
							<div class="description">
								Database server has reached its daily capicity
							</div>
							<div class="date pull-left">
								2 mins ago
							</div>
						</div>
						<div class="clearfix"></div>
					</div>
				</div>
			</div>

			<div class="pull-right">
				<ul class="nav quick-section ">
					<li class="quicklinks">
						<a data-toggle="dropdown" class="dropdown-toggle  pull-right " href="#" id="user-options">
							<div class="chat-toggler sm">
								<div class="profile-pic">
								@if(Auth::user()->profile_picture!='')
									<img src="{{ asset(Auth::user()->profile_picture) }}" alt="">
								
								@else
									
									@if(Auth::user()->gender =='male')
										<img name='display_pic' id='profile_pic' src="/assets/img/profiles/male-user.jpg" alt="">    
									@else
										<img name='display_pic' id='profile_pic' src="/assets/img/profiles/female-user.jpg" alt="">    
									@endif                                                                
																											
								@endif 
									<!--<img src="../assets/img/profiles/arshad-small.jpg" alt=""/>-->
								</div>
							</div>
						</a>

						<ul class="dropdown-menu  pull-right" role="menu" aria-labelledby="user-options">
							<li><a href=" {{ route('user.profile') }} "> My Account</a></li>
							<li class="divider"></li>
							<li><a href="{{ route('logout') }}"><i class="fa fa-power-off"></i>&nbsp;&nbsp;Log Out</a></li>
						</ul>
					</li>


				</ul>
			</div>

		</div>

	</div>

</div>