<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="content-type" content="text/html;charset=UTF-8"/>
	<meta charset="utf-8"/>
	<title>QUOFLY - Enterprise Resource Planning, ERP System</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
	<meta content="" name="Enterprise Resource Planning, ERP System"/>
	<meta content="" name="AK Information Technology Bahrain"/>

	<link rel="icon" type="image/png" href="assets/img/favicon.png"/>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt" crossorigin="anonymous">
	<link href="assets/plugins/pace/pace-theme-flash.css" rel="stylesheet" type="text/css" media="screen"/>
	<link href="assets/plugins/bootstrapv3/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
	<link href="assets/plugins/bootstrapv3/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css"/>
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<link href="assets/plugins/animate.min.css" rel="stylesheet" type="text/css"/>
	<link href="assets/plugins/jquery-scrollbar/jquery.scrollbar.css" rel="stylesheet" type="text/css"/>
	<link href="quofly/css/quofly.css" rel="stylesheet" type="text/css"/>

</head>

<body class="error-body no-top">
	<div class="error-wrapper container">
		<div class="row">
			<div class="col-md-4 col-md-offset-4 col-sm-6 col-sm-offset-3 col-xs-offset-1 col-xs-10">
				<div class="error-container">
					<div class="error-main">
						<div class="error-number"> 404 </div>
						<div class="error-description"> We seem to have lost you in the clouds. </div>
						<div class="error-description-mini"> The page your looking for is not here </div>

					</div>
				</div>
			</div>
		</div>
	</div>
	<div id="footer">
		<div class="error-container">
			<ul class="footer-links small-links">
				<li><a href="http://quofly.com/copyright">Copyrights & Privacy </a>
				</li>
				<li><a href="http://quofly.com/faq">Help &amp; FAQ</a>
				</li>
				<li><a href="http://quofly.com/contact">Contact Us</a>
				</li>
				<li><a href="http://quofly.com/">Home</a>
				</li>
				<li><a href="http://quofly.com/about">About Us </a>
				</li>
				<li><a href="http://quofly.com/features">App Features</a>
				</li>
			</ul>
			<br>
			<div class="copyright"> Made with <i class="fa fa-heart"></i> from <a href="http://quofly.com/">Quofly Team</a> </div>
		</div>
	</div>

	<script src="assets/plugins/pace/pace.min.js" type="text/javascript"></script>

	<script src="assets/plugins/jquery/jquery-3.3.1.min.js" type="text/javascript"></script>
	<script src="assets/plugins/bootstrapv3/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="assets/plugins/jquery-block-ui/jqueryblockui.min.js" type="text/javascript"></script>
	<script src="assets/plugins/jquery-unveil/jquery.unveil.min.js" type="text/javascript"></script>
	<script src="assets/plugins/jquery-scrollbar/jquery.scrollbar.min.js" type="text/javascript"></script>
	<script src="assets/plugins/jquery-numberAnimate/jquery.animateNumbers.js" type="text/javascript"></script>
	<script src="assets/plugins/jquery-validation/js/jquery.validate.min.js" type="text/javascript"></script>
	<script src="assets/plugins/bootstrap-select2/select2.min.js" type="text/javascript"></script>

	<script src="quofly/js/quofly.js" type="text/javascript"></script>

</body>
</html>