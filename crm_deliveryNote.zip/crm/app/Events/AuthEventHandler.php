<?php
namespace App\Events;

use App\Model\User;
use App\Model\UserLogin;
use Request;

use Illuminate\Broadcasting\Channel;
use Illuminate\Queue\SerializesModels;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;

class AuthEventHandler
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    /**
     * Create a new event instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Get the channels the event should broadcast on.
     *
     * @return \Illuminate\Broadcasting\Channel|array
     */
    public function broadcastOn()
    {
        return new PrivateChannel('channel-name');
    }
/*
    public function onUserLogin(User $user)
    {
       // print_r($user);
       // exit;
        //'userid','ipaddress','session_id','login_at','logout_at','status','created_at','updated_at'
        $now=date('Y-m-d H:i:s');
        $login = new Userlog();
        $login->userid =  isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '0';
        $login->ipaddress = Request::getClientIp();
        $login->session_id = session()->getId();
        $login->login_at=$now;
        $login->logout_at=$now;
        $login->status=1;
        $login->created_at=$now;
        $login->updated_at=$now;
        $login->user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : 'none';
        
        $user->logins()->save($login);
    }

    public function onUserLogout(User $user)
    {
        print_r($user);
        exit;
        $login = $user->logins()->where('session_id', session()->getId())->first();
        if ($login) {
            

            $now=date('Y-m-d H:i:s');
            $login = new Userlog();
            $login->logout_at=$now;
            $login->status=1;
            $login->updated_at=$now;
            $login->save();
        }

        $ret=DB::table('users')
            ->where("users.id", '=',  $_POST['id'])
            ->update(['users.password'=> $hashPassword,'updated_at'=>$now]);


    }

    public function handle($events)
    {
       // $events->listen('auth.login', 'App\Events\AuthEventHandler@onUserLogin');
       // $events->listen('auth.logout', 'App\Events\AuthEventHandler@onUserLogout');
    }
    */
}
