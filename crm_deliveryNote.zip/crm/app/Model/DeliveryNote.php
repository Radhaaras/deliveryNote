<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class DeliveryNote extends Model
{
    protected $table = 'deliverynotes';

    protected $fillable = [
        'id','companyid','companycode','deliverynotno','clientno','deliverynotecode','projectno', 'delivery_date','invoiceno','created_by','updated_by'
    ];
    
}
