<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Userlog extends Model
{
    protected $fillable = [
        //'name', 'email', 'password',
        'id','userid','ipaddress','session_id','login_at','last_active','logout_at','status','created_at','updated_at'
    ];   
}
