<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class DeliveryNoteContent extends Model
{
    protected $table = 'dncontents';

    protected $fillable = [
        'id','companyid','companycode','deliverynoteno','slno','description', 'quantity','created_by','updated_by','created_at','updated_at'
    ];

}
