<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class RolePermission extends Model
{
    protected $fillable = [
        'id','date','roleid', 'menuid','view','edit', 'delete','print',
    ];

    public function role_permission()
    {
        return $this->hasMany('user\permission');
    }
}
