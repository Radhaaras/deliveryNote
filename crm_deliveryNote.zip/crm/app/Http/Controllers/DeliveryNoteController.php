<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Model\DeliveryNote;
use App\Model\DeliveryNoteContent;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\URL;

class DeliveryNoteController extends Controller
{
    public function createDeliveryNote(Request $request){
     
        $invoice = \DB::table('invoices')
        ->where('id','=',6)
        ->get();
        
        $invoice_content = \DB::table('invoice_contents')
        ->where('invoice_id','=',6)
        ->get();
       // print_r($invoice_content);
        //exit;
        $company = \DB::table('company')
        ->where('id','=',Auth::user()->companyid)
        ->get();
       
        $client=\DB::table('clients')
        ->where('client_id','=',$invoice[0]->client_id)
        ->where('company_id','=',Auth::user()->companyid)
        ->get();

        $role = \DB::table('roles')->get();
        return view('pages.deliverynote.createdeliverynote', compact('invoice','invoice_content','company','client','role') );
        

        //return view('pages.users.createUser', compact('roleTable','rolePermissions') );
    }  
    public  function deliveryNoteSave(Request $request){
      //  print_r($_POST);
        
        //$maxdn=DB::table('deliverynotes')->max('deliverynoteno')->get();
        $dn = DB::table('deliverynotes');
        $maxid=$dn->max('deliverynoteno');
        if($maxid){
            $maxid=$maxid+1;
        }
        else{
            //$maxid=sprintf('%05d', 1);
            $maxid=1;
        }
        
            $dn = new DeliveryNote;
            $dn->companyid=$request->session()->get('companyid');
            $dn->companycode=$request->session()->get('companycode');
            $dn->deliverynoteno=$maxid;
            $dn->deliverynotecode=str_pad($maxid,5,'0',STR_PAD_LEFT);
            $dn->clientno=$request->clientno;
            $dn->projectno=$request->projectno;
            $dn->delivery_date=date('Y-m-d', strtotime($request->delivery_date));
            $dn->invoiceno=$request->invoiceno;
            $dn->created_by=Auth::User()->id;
            $dn->updated_by='';
            $dn->created_at=date('Y-m-d H:i:s');
            $dn->updated_at=date('Y-m-d H:i:s');
            $insert=$dn->save();
        
        
       
               foreach($_POST as $key => $value){
                    $exp_key = explode('description', $key);
                    if(isset($exp_key[1])){
                       $pkt[]=$exp_key[1];
                    }
                }
                $j=1;
                for($i=0;$i<count($pkt);$i++){
                    $description='description'.$pkt[$i];
                    $quantity='quantity'.$pkt[$i];
                    $dnc = new DeliveryNoteContent;
                    $dnc->companyid=$request->session()->get('companyid');
                    $dnc->companycode=$request->session()->get('companycode');
                    $dnc->deliverynoteno=$maxid;
                    $dnc->slno=$j;
                    $dnc->description=$request->$description;
                    $dnc->quantity=$request->$quantity;
                    $dnc->created_by=Auth::User()->id;
                    $dnc->updated_by='';
                    $dnc->created_at=date('Y-m-d H:i:s');
                    $dnc->updated_at=date('Y-m-d H:i:s');
                    $insert=$dnc->save();
                    $j++;
                }
               
          $user_role_permission = DB::table('users')
            ->join('roles', 'users.role', '=', 'roles.roleid')
            ->join('role_permissions', 'roles.roleid', '=', 'role_permissions.roleid')
            ->join('company', 'company.id', '=', 'users.companyid')
            ->where('users.status','=',1)
            ->where('users.email','=',Auth::user()->email)
            ->where('users.companyid','=',Auth::user()->companyid)
            ->orderBy('role_permissions.menuid', 'ASC')
            ->select('users.*', 'roles.*', 'role_permissions.*')
            ->get();
            $user_role='';
            foreach($user_role_permission as $urp){
                if($urp->menuid==6){
                    $user_role=$urp;
                    break;
                }
            }
            if($user_role->role!=1 || $user_role->supervisor!=1){
                $user = \DB::table('users')->get();
        
                $deliveryNote = \DB::table('deliverynotes')
                ->orderBY('deliverynoteno','DESC')
                ->get();
                
                $invoice = \DB::table('invoices')
                ->where('id','=',6)
                ->get();
                
                $invoice_content = \DB::table('invoice_contents')
                ->where('invoice_id','=',6)
                ->get();
            // print_r($invoice_content);
                //exit;
                $company = \DB::table('company')
                ->where('id','=',Auth::user()->companyid)
                ->get();
            
                $client=\DB::table('clients')
                ->get();
                $poc=\DB::table('point_of_contacts')
                ->get();
                $role = \DB::table('roles')->get();    
                $quotation  =DB::table('quotations')
                        ->select('client_id', DB::raw('count(client_id) as client_count'))
                        ->groupBy('client_id')
                        ->orderBy('client_id')
                        ->get();
            }
            else{
                $user = \DB::table('users')->get();
        
                $deliveryNote = \DB::table('deliverynotes')
                ->where('created_by','=',Auth::user()->id)
                ->orderBY('deliverynoteno','DESC')
                ->get();
                
                $invoice = \DB::table('invoices')
                ->where('id','=',6)
                ->get();
                
                $invoice_content = \DB::table('invoice_contents')
                ->where('invoice_id','=',6)
                ->get();
            // print_r($invoice_content);
                //exit;
                $company = \DB::table('company')
                ->where('id','=',Auth::user()->companyid)
                ->get();
            
                $client=\DB::table('clients')
                ->get();
                $poc=\DB::table('point_of_contacts')
                ->get();
                $role = \DB::table('roles')->get();    
                $quotation  =DB::table('quotations')
                        ->select('client_id', DB::raw('count(client_id) as client_count'))
                        ->groupBy('client_id')
                        ->orderBy('client_id')
                        ->get();

            }
         //   return redirect()->route('profile', ['id' => 1]);
         //return Redirect::to('pages/deliverynote/viewdeliverynote')->with(['user',$user],['deliveryNote',$deliveryNote],['invoice',$invoice],['invoice_content',$invoice_content],['company',$company],['client',$client],['role',$role],['poc',$poc],['quotation',$quotation],['maxid',$maxid],['success','Delivery Note Created Successfully']);
         return view('pages.deliverynote.viewdeliverynote', compact('user','deliveryNote','invoice','invoice_content','company','client','role','poc','quotation','maxid'))->with('success','Delivery Note Created Successfully');

    }  
    public function deliveryNoteUpdate(Request $request){
     //  print_r($_POST);
      // exit;
            $result=DB::table('deliverynotes')
            ->where('deliverynoteno','=',$request->deliverynoteno)
            ->update([
                'delivery_date'=>date('Y-m-d', strtotime($request->delivery_date)),
                'updated_by'=>Auth::User()->id,
                'updated_at'=>date('Y-m-d H:i:s'),
            ]);
            $deliverynote = DeliveryNoteContent::where('deliverynoteno', '=', $request->deliverynoteno)->delete();
       
               foreach($_POST as $key => $value){
                    $exp_key = explode('description', $key);
                    if(isset($exp_key[1])){
                       $pkt[]=$exp_key[1];
                    }
                }
                $j=1;
                for($i=0;$i<count($pkt);$i++){
                    $description='description'.$pkt[$i];
                    $quantity='quantity'.$pkt[$i];
                    $dnc = new DeliveryNoteContent;
                    $dnc->companyid=$request->session()->get('companyid');
                    $dnc->companycode=$request->session()->get('companycode');
                    $dnc->deliverynoteno=$request->deliverynoteno;
                    $dnc->slno=$j;
                    $dnc->description=$request->$description;
                    $dnc->quantity=$request->$quantity;
                    $dnc->created_by=Auth::User()->id;
                    $dnc->updated_by=Auth::User()->id;
                    $dnc->created_at=date('Y-m-d H:i:s');
                    $dnc->updated_at=date('Y-m-d H:i:s');
                    $insert=$dnc->save();
                    $j++;
                }
                $user_role_permission = DB::table('users')
            ->join('roles', 'users.role', '=', 'roles.roleid')
            ->join('role_permissions', 'roles.roleid', '=', 'role_permissions.roleid')
            ->join('company', 'company.id', '=', 'users.companyid')
            ->where('users.status','=',1)
            ->where('users.email','=',Auth::user()->email)
            ->where('users.companyid','=',Auth::user()->companyid)
            ->orderBy('role_permissions.menuid', 'ASC')
            ->select('users.*', 'roles.*', 'role_permissions.*')
            ->get();
            $user_role='';
            foreach($user_role_permission as $urp){
                if($urp->menuid==6){
                    $user_role=$urp;
                    break;
                }
            }
            if($user_role->role!=1 || $user_role->supervisor!=1){
                $user = \DB::table('users')->get();
        
                $deliveryNote = \DB::table('deliverynotes')->get();
                
                $invoice = \DB::table('invoices')
                ->where('id','=',6)
                ->get();
                
                $invoice_content = \DB::table('invoice_contents')
                ->where('invoice_id','=',6)
                ->get();
            // print_r($invoice_content);
                //exit;
                $company = \DB::table('company')
                ->where('id','=',Auth::user()->companyid)
                ->get();
            
                $client=\DB::table('clients')
                ->get();
                $poc=\DB::table('point_of_contacts')
                ->get();
                $role = \DB::table('roles')->get();    
                $quotation  =DB::table('quotations')
                        ->select('client_id', DB::raw('count(client_id) as client_count'))
                        ->groupBy('client_id')
                        ->orderBy('client_id')
                        ->get();
            }
            else{
                $user = \DB::table('users')->get();
        
                $deliveryNote = \DB::table('deliverynotes')
                ->where('created_by','=',Auth::user()->id)
                ->get();
                
                $invoice = \DB::table('invoices')
                ->where('id','=',6)
                ->get();
                
                $invoice_content = \DB::table('invoice_contents')
                ->where('invoice_id','=',6)
                ->get();
            // print_r($invoice_content);
                //exit;
                $company = \DB::table('company')
                ->where('id','=',Auth::user()->companyid)
                ->get();
            
                $client=\DB::table('clients')
                ->get();
                $poc=\DB::table('point_of_contacts')
                ->get();
                $role = \DB::table('roles')->get();    
                $quotation  =DB::table('quotations')
                        ->select('client_id', DB::raw('count(client_id) as client_count'))
                        ->groupBy('client_id')
                        ->orderBy('client_id')
                        ->get();

            }
            
        
        $maxid=0;
        //SELECT client_id,count(id) FROM `quotations` group by `client_id` order by 
        return view('pages.deliverynote.viewdeliverynote', compact('user','deliveryNote','invoice','invoice_content','company','client','role','poc','quotation','maxid'));

    }
    public function viewDeliveryNote(){
        $user_role_permission = DB::table('users')
            ->join('roles', 'users.role', '=', 'roles.roleid')
            ->join('role_permissions', 'roles.roleid', '=', 'role_permissions.roleid')
            ->join('company', 'company.id', '=', 'users.companyid')
            ->where('users.status','=',1)
            ->where('users.email','=',Auth::user()->email)
            ->where('users.companyid','=',Auth::user()->companyid)
            ->orderBy('role_permissions.menuid', 'ASC')
            ->select('users.*', 'roles.*', 'role_permissions.*')
            ->get();
            $user_role='';
            foreach($user_role_permission as $urp){
                if($urp->menuid==6){
                    $user_role=$urp;
                    break;
                }
            }
            if($user_role->role==1 || $user_role->supervisor==1){
                
                $user = \DB::table('users')->get();
        
                $deliveryNote = \DB::table('deliverynotes')->get();
                
                $invoice = \DB::table('invoices')
                ->where('id','=',6)
                ->get();
                
                $invoice_content = \DB::table('invoice_contents')
                ->where('invoice_id','=',6)
                ->get();
            // print_r($invoice_content);
                //exit;
                $company = \DB::table('company')
                ->where('id','=',Auth::user()->companyid)
                ->get();
            
                $client=\DB::table('clients')
                ->get();
                $poc=\DB::table('point_of_contacts')
                ->get();
                $role = \DB::table('roles')->get();    
                $quotation  =DB::table('quotations')
                        ->select('client_id', DB::raw('count(client_id) as client_count'))
                        ->groupBy('client_id')
                        ->orderBy('client_id')
                        ->get();
            }
            else{
                $user = \DB::table('users')->get();
        
                $deliveryNote = \DB::table('deliverynotes')
                ->where('created_by','=',Auth::user()->id)
                ->get();
                
                $invoice = \DB::table('invoices')
                ->where('id','=',6)
                ->get();
                
                $invoice_content = \DB::table('invoice_contents')
                ->where('invoice_id','=',6)
                ->get();
            // print_r($invoice_content);
                //exit;
                $company = \DB::table('company')
                ->where('id','=',Auth::user()->companyid)
                ->get();
            
                $client=\DB::table('clients')
                ->get();
                $poc=\DB::table('point_of_contacts')
                ->get();
                $role = \DB::table('roles')->get();    
                $quotation  =DB::table('quotations')
                        ->select('client_id', DB::raw('count(client_id) as client_count'))
                        ->groupBy('client_id')
                        ->orderBy('client_id')
                        ->get();

            }
            
        
            $maxid=0;
            //SELECT client_id,count(id) FROM `quotations` group by `client_id` order by 
            return view('pages.deliverynote.viewdeliverynote', compact('user','deliveryNote','invoice','invoice_content','company','client','role','poc','quotation','maxid'));
    
    }
    public function sortdeliverynoteajax($sortorder){
        $user_role_permission = DB::table('users')
            ->join('roles', 'users.role', '=', 'roles.roleid')
            ->join('role_permissions', 'roles.roleid', '=', 'role_permissions.roleid')
            ->join('company', 'company.id', '=', 'users.companyid')
            ->where('users.status','=',1)
            ->where('users.email','=',Auth::user()->email)
            ->where('users.companyid','=',Auth::user()->companyid)
            ->orderBy('role_permissions.menuid', 'ASC')
            ->select('users.*', 'roles.*', 'role_permissions.*')
            ->get();
            $user_role='';
            foreach($user_role_permission as $urp){
                if($urp->menuid==6){
                    $user_role=$urp;
                    break;
                }
            }
            if($user_role->role!=1 || $user_role->supervisor!=1){
                switch($sortorder){
                    case 1:{
                        $deliveryNote = \DB::table('deliverynotes')->get();

                    }break;
                    case 2:{
                        $deliveryNote = \DB::table('deliverynotes')
                        ->orderBy('delivery_date','ASC')
                        ->get();
                        
                    }break;
                    case 3:{
                        $deliveryNote = \DB::table('deliverynotes')
                        ->orderBy('created_at','ASC')
                        ->get();
                        
                    }break;
                    case 4:{
                        $deliveryNote = \DB::table('deliverynotes')
                        ->orderBy('created_at','DESC')
                        ->get();                        
                    }break;
        
                }
               
                $user = \DB::table('users')->get();
        
                
                
                $invoice = \DB::table('invoices')
                ->where('id','=',6)
                ->get();
                
                $invoice_content = \DB::table('invoice_contents')
                ->where('invoice_id','=',6)
                ->get();
            // print_r($invoice_content);
                //exit;
                $company = \DB::table('company')
                ->where('id','=',Auth::user()->companyid)
                ->get();
            
                $client=\DB::table('clients')
                ->get();
                $poc=\DB::table('point_of_contacts')
                ->get();
                $role = \DB::table('roles')->get();    
                $quotation  =DB::table('quotations')
                        ->select('client_id', DB::raw('count(client_id) as client_count'))
                        ->groupBy('client_id')
                        ->orderBy('client_id')
                        ->get();
            }
            else{
                switch($sortorder){
                    case 1:{
                        $deliveryNote = \DB::table('deliverynotes')
                        ->where('created_by','=',Auth::user()->id)
                        ->get();

                    }break;
                    case 2:{
                        $deliveryNote = \DB::table('deliverynotes')
                        ->where('created_by','=',Auth::user()->id)
                        ->orderBy('delivery_date','ASC')
                        ->get();
                        
                    }break;
                    case 3:{
                        $deliveryNote = \DB::table('deliverynotes')
                        ->where('created_by','=',Auth::user()->id)
                        ->orderBy('created_at','ASC')
                        ->get();
                        
                    }break;
                    case 4:{
                        $deliveryNote = \DB::table('deliverynotes')
                        ->where('created_by','=',Auth::user()->id)
                        ->orderBy('created_at','DESC')
                        ->get();                        
                    }break;
        
                }
                $user = \DB::table('users')->get();
        
                $deliveryNote = \DB::table('deliverynotes')
                
                ->get();
                
                $invoice = \DB::table('invoices')
                ->where('id','=',6)
                ->get();
                
                $invoice_content = \DB::table('invoice_contents')
                ->where('invoice_id','=',6)
                ->get();
            // print_r($invoice_content);
                //exit;
                $company = \DB::table('company')
                ->where('id','=',Auth::user()->companyid)
                ->get();
            
                $client=\DB::table('clients')
                ->get();
                $poc=\DB::table('point_of_contacts')
                ->get();
                $role = \DB::table('roles')->get();    
                $quotation  =DB::table('quotations')
                        ->select('client_id', DB::raw('count(client_id) as client_count'))
                        ->groupBy('client_id')
                        ->orderBy('client_id')
                        ->get();

            }
            $maxid=0;
            //SELECT client_id,count(id) FROM `quotations` group by `client_id` order by 
            return view('pages.deliverynote.viewdeliverynote', compact('user','deliveryNote','invoice','invoice_content','company','client','role','poc','quotation','maxid'));
    
        
    }
    public function editdeliveryNote($deliverynoteid){
        //echo $deliverynoteid;
        $deliveryNote = \DB::table('deliverynotes')
            ->where('id','=',$deliverynoteid)
            ->get();
            //print_r($deliveryNote);
           // exit;
        $deliveryNote_content= \DB::table('dncontents')
        ->where('deliverynoteno','=',$deliveryNote[0]->deliverynoteno)
        ->orderBY('slno')
        ->get();
        //print_r($deliveryNote_content);
        //exit;
        $invoice = \DB::table('invoices')
        ->where('invoice_code','=',$deliveryNote[0]->invoiceno)
        ->get();
        
        $company = \DB::table('company')
        ->where('id','=',$deliveryNote[0]->companyid)
        ->get();
       
        $client=\DB::table('clients')
        ->where('client_id','=',$deliveryNote[0]->clientno)
        ->get();

        $role = \DB::table('roles')->get();
        return view('pages.deliverynote.editdeliverynote', compact('deliveryNote','deliveryNote_content','invoice','company','client','role') );
    }
    public function readonlydeliveryNote($deliverynoteid){
        
        //echo $deliverynoteid;
        $deliveryNote = \DB::table('deliverynotes')
            ->where('id','=',$deliverynoteid)
            ->get();
            //print_r($deliveryNote);
           // exit;
        $deliveryNote_content= \DB::table('dncontents')
        ->where('deliverynoteno','=',$deliveryNote[0]->deliverynoteno)
        ->orderBY('slno')
        ->get();
        //print_r($deliveryNote_content);
        //exit;
        $invoice = \DB::table('invoices')
        ->where('invoice_code','=',$deliveryNote[0]->invoiceno)
        ->get();
        
        
        $company = \DB::table('company')
        ->where('id','=',$deliveryNote[0]->companyid)
        ->get();
       
        $client=\DB::table('clients')
        ->where('client_id','=',$deliveryNote[0]->clientno)
        ->get();

        $role = \DB::table('roles')->get();
        return view('pages.deliverynote.readonlydeliverynote', compact('deliveryNote','deliveryNote_content','invoice','company','client','role') );
    }
    public function deliveryNoteSearchAjax(Request $request){
       // print_r($_POST);
        $search=$_POST['searchString'];

            $deliveryNote=DB::table('deliverynotes')
            ->orwhere('deliverynoteno', 'LIKE', '%' . $search . '%')
            ->orWhere('deliverynotecode', 'LIKE', '%' . $search . '%')
            ->get();
    
    
        $user_role_permission = DB::table('users')
            ->join('roles', 'users.role', '=', 'roles.roleid')
            ->join('role_permissions', 'roles.roleid', '=', 'role_permissions.roleid')
            ->join('company', 'company.id', '=', 'users.companyid')
            ->where('users.status','=',1)
            ->where('users.email','=',Auth::user()->email)
            ->where('users.companyid','=',Auth::user()->companyid)
            ->orderBy('role_permissions.menuid', 'ASC')
            ->select('users.*', 'roles.*', 'role_permissions.*')
            ->get();
            $user_role='';
            foreach($user_role_permission as $urp){
                if($urp->menuid==6){
                    $user_role=$urp;
                    break;
                }
            }
            if($user_role->role!=1 || $user_role->supervisor!=1){
                $user = \DB::table('users')->get();
        
                $invoice = \DB::table('invoices')
                ->get();
                
                $invoice_content = \DB::table('invoice_contents')
                ->get();
            // print_r($invoice_content);
                //exit;
                $company = \DB::table('company')
                ->where('id','=',Auth::user()->companyid)
                ->get();
            
                $client=\DB::table('clients')
                ->get();
                $poc=\DB::table('point_of_contacts')
                ->get();
                $role = \DB::table('roles')->get();    
                $quotation  =DB::table('quotations')
                        ->select('client_id', DB::raw('count(client_id) as client_count'))
                        ->groupBy('client_id')
                        ->orderBy('client_id')
                        ->get();
            }
            else{
                $user = \DB::table('users')->get();
         
                $invoice = \DB::table('invoices')
                ->get();
                
                $invoice_content = \DB::table('invoice_contents')
                ->get();
            // print_r($invoice_content);
                //exit;
                $company = \DB::table('company')
                ->where('id','=',Auth::user()->companyid)
                ->get();
            
                $client=\DB::table('clients')
                ->get();
                $poc=\DB::table('point_of_contacts')
                ->get();
                $role = \DB::table('roles')->get();    
                $quotation  =DB::table('quotations')
                        ->select('client_id', DB::raw('count(client_id) as client_count'))
                        ->groupBy('client_id')
                        ->orderBy('client_id')
                        ->get();

            }
            
        return array(['user'=>$user],['deliveryNote'=>$deliveryNote],['invoice'=>$invoice],['invoice_content'=>$invoice_content],['company'=>$company],['client'=>$client],['role'=>$role],['poc'=>$poc],['quotation'=>$quotation],['user_role'=>$user_role]);

            
    }

}
