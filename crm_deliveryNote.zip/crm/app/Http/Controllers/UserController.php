<?php
namespace App\Http\Controllers;


use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\UserRepository;
use App\Model\User;
use App\Model\Role;
use DB;
use Hash;
use Validator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Session;
use Cookie;
use App\Model\Userlog;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\URL;
use Crypt;

class UserController extends controller
{
	private $user;

	public function __construct(UserRepository $user) 
	{
		$this->User = $user;		
	}
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
		$data = $this->User->getall();
		return view('pages.dashboard');
    }
    public function userProfile(){
        if( isset(Auth::user()->id) ){
            $users = DB::table('users')
                ->where('id','=',Auth::user()->id)
                ->get(); 
            $roleTable = \DB::table('roles')->get();
            return view('pages.users.profile', compact('users','roleTable'));
        }else{
            
            $exp=0;
            \Cookie::queue(\Cookie::make('email','',$exp));
            \Cookie::queue(\Cookie::make('fullname','',$exp));
            \Cookie::queue(\Cookie::make('displayname','',$exp));
            \Cookie::queue(\Cookie::make('gender','',$exp));
            \Cookie::queue(\Cookie::make('profile_pic','',$exp));
            \Cookie::queue(\Cookie::make('image_type','',$exp));
            Auth::logout();
            return redirect('/login');
            
        }
    }
    public function signUploadAjax(Request $request){
        if (($request->hasFile('file'))) {
         
            $file = $request->file;
            //print_r($file);
            $extension = $request->file('file')->getClientOriginalExtension();
            $filetype=$request->file('file')->getClientOriginalExtension();
            
            $destination = 'assets/img/profiles/signature/';
            $imageName = $request->file('file')->getClientOriginalName();
            $file = $request->file('file');
            $filename = Auth::user()->id.'_signature.'.$file->getClientOriginalExtension();
            $result=$request->file('file')->move($destination,  $filename);
            
            $result=DB::table('users')
            ->where('id',Auth::user()->id)
            ->update([
                'signature'=>$destination.$filename,
                'signature_type'=>$filetype,
                'updated_by'=>Auth::User()->id,
                'updated_at'=>date('Y-m-d H:i:s'),
            ]);
            /*$destinationPath = 'uploads/files'; // upload path
            $extension = $request->file('file')->getClientOriginalExtension(); // getting image extension

            $tempName = $request->file("file")->getClientOriginalName();
            $fileName = uniqid("MW") . '.' . $extension; // renameing image
            $request->file('file')->move($destinationPath, $fileName); // uploading file to given path
            // sending back with message
            $imagepath = $destinationPath.'/'.$fileName;
            */
            return array(['success','Image Uploaded']);
        }
        return array(['failed','Image not selected']);

        

    }
    public function userProfileSave(Request $request){
       
        if ($request->has('form1')) {
           
            $rules = [
                    'upload_dp' => 'nullable | image:jpeg,jpg,png | max:2097152',
                    'signfile' => 'nullable | image:jpeg,jpg,png | max:2097152',
                    'fullname' => 'required|min:3|max:50',
                    'displayname' => 'required|min:2|max:10',
                    'gender' => 'required|in:"male","female"',
                    'phone' => 'required|digits_between:8,15',
                    'otherphone' => 'numeric|digits_between:8,15|nullable',
                    'cprexpiry' => 'date|nullable',
                    'passportexpiry' => 'date|nullable',
                    'visaexpiry' => 'date|nullable',
                    'dlexpiry' => 'date|nullable',
                    'dob' => 'date|nullable',

                    'paddress' => 'required|min:3|max:25',
                    'pcity' => 'required|min:3|max:25',
                    'pstate' => 'required|min:3|max:25',
                    'pcountry' => 'required|min:3|max:25',
                    'pcountrycode' => 'numeric|nullable',
                    'pphonenumber' => 'numeric|digits_between:8,15|nullable',
                    
                    'caddress' => 'required|min:3|max:25',
                    'ccity' => 'required|min:3|max:25',
                    'cstate' => 'required|min:3|max:25',
                    'ccountry' => 'required|min:3|max:25',
                    'ccountrycode' => 'numeric|nullable',
                    'cphonenumber' => 'numeric|digits_between:8,15|nullable',
                    
                   
                ];
                $messsages = array(
                    'upload_dp.image' => 'Upload image of type jpeg ,jpg or png' ,
                    'upload_dp.max' => 'Max image size is 2097152 byte',
                    'signfile.image' => 'Upload image of type jpeg ,jpg or png' ,
                    'signfile.max' => 'Max image size is 2097152 byte',
                    
                    'fullname.required' => 'Enter Full Name',
                    'fullname.min' => 'Enter Minimum 3 character',
                    'fullname.max' => 'Enter Max Limit 50 character',
                    'displayname.required' => 'Enter Display Name',
                    'displayname.min' => 'Enter Minimum 2 character',
                    'displayname.max' => 'Enter Max Limit 10 character',
                    'gender.required' => 'Select Gender',
                    'phone.required' => 'Enter Phone Number',
                    'phone.numeric' => 'Enter Numbers only',
                    'phone.digits_between' => 'Enter Digits Between 8 to 15',
                    'otherphone.numeric' => 'Enter Numbers only',
                    'otherphone.digits_between' => 'Enter Digits Between 8 to 15',
                    'cprexpiry.date' => 'Enter Valid Date',
                    'dob.date' => 'Enter Valid Date',
                                    
                    'passportexpiry.date' => 'Enter Valid Date',
                    'visaexpiry.date' => 'Enter Valid Date',
                    'dlexpiry.date' => 'Enter Valid Date',
                    
                    'paddress.required' => 'Permanent  Address is required',
                    'paddress.required' => 'Enter Minimum 3 character',
                    'paddress.required' => 'Maximum limit 25 character',

                    'pcity.required' => 'Permanent  Address is required',
                    'pcity.required' => 'Enter Minimum 3 character',
                    'pcity.required' => 'Maximum limit 25 character',
                    
                    'pstate.required' => 'Permanent  Address is required',
                    'pstate.required' => 'Enter Minimum 3 character',
                    'pstate.required' => 'Maximum limit 25 character',

                    'pcountry.required' => 'Permanent  Address is required',
                    'pcountry.required' => 'Enter Minimum 3 character',
                    'pcountry.required' => 'Maximum limit 25 character',

                    'pcountrycode.numeric' => 'Enter only Digits',
                    'pphonenumber.numeric' => 'Enter only Digits',
                    'pphonenumber.digits_between' => 'Enter Digits Between 8 to 15',
                   
                    'caddress.required' => 'Permanent  Address is required',
                    'caddress.required' => 'Enter Minimum 3 character',
                    'caddress.required' => 'Maximum limit 25 character',

                    'ccity.required' => 'Permanent  Address is required',
                    'ccity.required' => 'Enter Minimum 3 character',
                    'ccity.required' => 'Maximum limit 25 character',
                    
                    'cstate.required' => 'Permanent  Address is required',
                    'cstate.required' => 'Enter Minimum 3 character',
                    'cstate.required' => 'Maximum limit 25 character',

                    'ccountry.required' => 'Permanent  Address is required',
                    'ccountry.required' => 'Enter Minimum 3 character',
                    'ccountry.required' => 'Maximum limit 25 character',

                    'ccountrycode.numeric' => 'Enter only Digits',
                    'cphonenumber.numeric' => 'Enter only Digits',
                    'cphonenumber.digits_between:8,13' => 'Enter Digits Between 8 to 15',

                );
                 $validator = Validator::make($request->all(), $rules, $messsages);
                
                if($validator->fails()){ 
                    //echo "validator Fails";
                   return redirect()->back()->withInput()->withErrors($validator);
                
                
                }
                else{
                   // print_r($request->all());exit;
                    $result=DB::table('users')
                    ->where('id',Auth::user()->id)
                    ->update([
                    'fullname'=>$request->fullname,
                    'displayname'=>$request->displayname,
                    'gender'=>$request->gender,
                    'phone'=>$request->phone,
                    'otherphone'=>$request->otherphone,
                    'cprexpiry'=>date('Y-m-d',strtotime($request->cprexpiry)),
                    'passportnumber'=>$request->passportnumber,
                    'passportexpiry'=>date('Y-m-d',strtotime($request->passportexpiry)),
                    'dob' => date('Y-m-d',strtotime($request->dob)),
                    'nationality' => $request->nationality,
                    'dl'=>$request->dl,
                    'dlexpiry'=>date('Y-m-d',strtotime($request->dlexpiry)),
                    'paddress'=>$request->paddress,
                    'pcity'=>$request->pcity,
                    'pstate'=>$request->pstate,
                    'pcountry'=>$request->pcountry,
                    'ppost'=>$request->ppost,
                    'pcountrycode'=>$request->pcountrycode,
                    'pphonenumber'=>$request->pphonenumber,
                    'caddress'=>$request->caddress,
                    'ccity'=>$request->ccity,
                    'cstate'=>$request->cstate,
                    'ccountry'=>$request->ccountry,
                    'cpost'=>$request->cpost,
                    'ccountrycode'=>$request->ccountrycode,
                    'cphonenumber'=>$request->cphonenumber,
                    'cphonenumber'=>$request->cphonenumber,
                    'updated_by'=>Auth::User()->id,
                    'updated_at'=>date('Y-m-d H:i:s'),
                    ]);
                    
                    //print_r($insert);
                        if($request->upload_dp!=''){
                            $file = $request->file;
                            $filetype=$request->upload_dp->getClientOriginalExtension();
                            
                            $destination = 'assets/img/profiles/user_profile/';
                            $imageName = $request->file('upload_dp')->getClientOriginalName();
                            $file = $request->file('upload_dp');
                            $filename = Auth::user()->id.'_displaypic.'.$file->getClientOriginalExtension();
                            $result=$request->file('upload_dp')->move($destination,  $filename);
                            
                       /*
                            $user = User::find(Auth::user()->id);
                            $user->profile_picture=$destination.$filename;
                            $user->image_type=$filetype;
                            $insertinside=$user->save();
*/
                            $result=DB::table('users')
                            ->where('id',Auth::user()->id)
                            ->update([
                                'profile_picture'=>$destination.$filename,
                                'image_type'=>$filetype,
                                'updated_by'=>Auth::User()->id,
                                'updated_at'=>date('Y-m-d H:i:s'),
                                ]);
                        }
                        else{
                            $result=DB::table('users')
                            ->where('id',Auth::user()->id)
                            ->update([
                                'profile_picture'=>"",
                                'image_type'=>"",
                                'updated_by'=>Auth::User()->id,
                                'updated_at'=>date('Y-m-d H:i:s'),
                                ]);

                        }
                        if($request->signfile!=''){
                            $file = $request->file;
                            $filetype=$request->signfile->getClientOriginalExtension();
                            
                            $destination = 'assets/img/profiles/signature/';
                            $imageName = $request->file('signfile')->getClientOriginalName();
                            $file = $request->file('signfile');
                            $filename = Auth::user()->id.'_signature.'.$file->getClientOriginalExtension();
                            $result=$request->file('signfile')->move($destination,  $filename);
                            
                            $result=DB::table('users')
                            ->where('id',Auth::user()->id)
                            ->update([
                                'signature'=>$destination.$filename,
                                'signature_type'=>$filetype,
                                'updated_by'=>Auth::User()->id,
                                'updated_at'=>date('Y-m-d H:i:s'),
                            ]);
                           
                        }
                        else{
                            $result=DB::table('users')
                            ->where('id',Auth::user()->id)
                            ->update([
                                'signature'=>"",
                                'signature_type'=>"",
                                'updated_by'=>Auth::User()->id,
                                'updated_at'=>date('Y-m-d H:i:s'),
                            ]);

                        }
                        $users = DB::table('users')
                        ->where('id','=',Auth::user()->id)
                        ->get(); 
                        $roleTable = \DB::table('roles')->get();
                        $message='Profile Updated';
                        
                        return redirect()->route('user.profile')->with(['users' => $users, 'roleTable' => $roleTable])->with('success',$message);
                    }
                }
            
                if ($request->has('form2')) {
                 
                    $rules = [
                    'password' => 'min:4|required_with:change_password|same:change_password',
                    'change_password' => 'min:4'
                    ];
                    $messsages = array(
                        'password.min' => 'Enter Atleast 4 character',
                        'password.required_with' => 'Password Not Matching',
                        'change_password.min' => 'Enter Atleast 4 character',
                    );
                     $validator = Validator::make($request->all(), $rules, $messsages);
                    
                    if($validator->fails()){ 
                        //echo "validator Fails";
                       return redirect()->back()->withInput(['tab'=>'change-password'])->withErrors($validator);
                    }
                    else{
                        $hashPassword=Hash::make($request->password);
                        $now=date('Y-m-d H:i:s');
                        $ret=DB::table('users')
                            ->where("users.id", '=',  Auth::user()->id)
                            ->update(['users.password'=> $hashPassword,'updated_at'=>$now]);
                       // print_r(Auth::user());
                        $user = Auth::user();
                        $user->password = $hashPassword;
                       
                       return redirect()->back()->withInput(['tab'=>'change-password'])->with("status","Password has been changed successfully.");
                       }
                    }
                }
        

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function createuser()
    {
        $roleTable = \DB::table('roles')
        ->where('roleid','!=',1)
        ->where('status','=',1)
        ->get();
        
        $rolePermissions = \DB::table('role_permissions')->get();
        return view('pages.users.createUser', compact('roleTable','rolePermissions') );
    }
    public function userValidationAjax( Request $request ){
        
       
        $rules = [
                'upload_dp' => 'image:jpeg,jpg,png | max:2097152 | nullable',
                'fullname' => 'required|min:3|max:50',
                'displayname' => 'required|min:2|max:10',
                'gender' => 'required|in:"male","female"',
                'phone' => 'required|digits_between:8,15',
                'otherphone' => 'nullable|numeric|digits_between:8,15',
                'email' => 'required|email|unique:users,email',
                'password' => 'required',
                'designation' => 'required',
                'cpr' => 'numeric|digits:9|nullable',
                'cprexpiry' => 'date|nullable',
                'dob' => 'date|nullable',
                'passportexpiry' => 'date|nullable',
                'visaexpiry' => 'date|nullable',
                'dlexpiry' => 'date|nullable',
                'pcountrycode' => 'numeric|nullable',
                'pphonenumber' => 'numeric|digits_between:8,15|nullable',
                'ccountrycode' => 'numeric|nullable',
                'cphonenumber' => 'numeric|digits_between:8,15|nullable',
                
                
                
        ];
            $messsages = array(
                'upload_dp.image' => 'Upload image of type jpeg ,jpg or png' ,
                'upload_dp.max' => 'Max image size is 2 MB',
                'fullname.required' => 'Enter Full Name',
                'fullname.min' => 'Enter Minimum 3 character',
                'fullname.max' => 'Enter Max Limit 50 character',
                'displayname.required' => 'Enter Display Name',
                'displayname.min' => 'Enter Minimum 2 character',
                'displayname.max' => 'Enter Max Limit 10 character',
                'gender.required' => 'Select Gender',
                'phone.required' => 'Enter Phone Number',
                'phone.numeric' => 'Enter Numbers only',
                'phone.digits_between' => 'Enter Digits Between 8 to 15',
                'otherphone.numeric' => 'Enter Numbers only',
                'otherphone.digits_between' => 'Enter Digits Between 8 to 15',
                'email.required' => 'please Enter E-mail',
                'email.email' => 'Enter Valid E-mail',
                'email.unique' => 'E-mail already Exists',
                'password.required' => 'Please Enter Password',
                'designation.required' => 'Please Enter Designation',
                'cpr.numeric' => 'Enter Digits Only',
                'cpr.digits' => 'Enter only 9 Digits',
                'cprexpiry.date' => 'Enter Valid Date',
                'dob.date' => 'Enter Valid Date',
                'passportexpiry.date' => 'Enter Valid Date',
                'visaexpiry.date' => 'Enter Valid Date',
                'dlexpiry.date' => 'Enter Valid Date',
                'pcountrycode.numeric' => 'Enter only Digits',
                'pphonenumber.numeric' => 'Enter only Digits',
                'pphonenumber.digits_between' => 'Enter Digits Between 8 to 15',
                'ccountrycode.numeric' => 'Enter only Digits',
                'cphonenumber.numeric' => 'Enter only Digits',
                'cphonenumber.digits_between:8,15' => 'Enter Digits Between 8 to 15',
                
            );
            $params = array();
            parse_str($_POST['pkt'], $params);
            //print_r($params);
            $validator = Validator::make($params, $rules,[], $messsages);
            
            if($validator->fails()){ 
                return response()->json(['errors' => $validator->errors(), 'status' => 422], 200);
            }
            //return response()->json(['success' => 'validation success', 'status' => 200], 200);
            return ['success' => 'validation success', 'status' => 200];
            

    }
    public function createUserSave(Request $request){
        
            $rules = [
                'upload_dp' => 'nullable | image:jpeg,jpg,png | max:2097152',
                'fullname' => 'required|min:3|max:50',
                'displayname' => 'required|min:2|max:10',
                'gender' => 'required|in:"male","female"',
                'phone' => 'required|digits_between:8,15',
                'otherphone' => 'numeric|digits_between:8,15|nullable',
                'email' => 'required|email|unique:users,email',
                'password' => 'required',
                'cpr' => 'numeric|digits:9|nullable',
                'cprexpiry' => 'date|nullable',
                'dob' => 'date|nullable',
                'passportexpiry' => 'date|nullable',
                'visaexpiry' => 'date|nullable',
                'dlexpiry' => 'date|nullable',
                'pcountrycode' => 'numeric|nullable',
                'pphonenumber' => 'numeric|digits_between:8,15|nullable',
                'ccountrycode' => 'numeric|nullable',
                'cphonenumber' => 'numeric|digits_between:8,15|nullable',
                
                
                
        ];
            $messsages = array(
                'upload_dp.image' => 'Upload image of type jpeg ,jpg or png' ,
                'upload_dp.max' => 'Max image size is 2 MB',
                'fullname.required' => 'Enter Full Name',
                'fullname.min' => 'Enter Minimum 3 character',
                'fullname.max' => 'Enter Max Limit 10 character',
                'displayname.required' => 'Enter Display Name',
                'displayname.min' => 'Enter Minimum 2 character',
                'displayname.max' => 'Enter Max Limit 50 character',
                'gender.required' => 'Select Gender',
                'phone.required' => 'Enter Phone Number',
                'phone.numeric' => 'Enter Numbers only',
                'phone.digits_between' => 'Enter Digits Between 8 to 15',
                'otherphone.numeric' => 'Enter Numbers only',
                'otherphone.digits_between' => 'Enter Digits Between 8 to 15',
                'email.required' => 'please Enter E-mail',
                'email.email' => 'Enter Valid E-mail',
                'email.unique' => 'E-mail already Exists',
                'password.required' => 'Please Enter Password',
                'cpr.numeric' => 'Enter Digits Only',
                'cpr.digits' => 'Enter only 9 Digits',
                'cprexpiry.date' => 'Enter Valid Date',
                'dob.date' => 'Enter Valid Date',
                'passportexpiry.date' => 'Enter Valid Date',
                'visaexpiry.date' => 'Enter Valid Date',
                'dlexpiry.date' => 'Enter Valid Date',
                'pcountrycode.numeric' => 'Enter only Digits',
                'pphonenumber.numeric' => 'Enter only Digits',
                'pphonenumber.digits_between' => 'Enter Digits Between 8 to 15',
                'ccountrycode.numeric' => 'Enter only Digits',
                'cphonenumber.numeric' => 'Enter only Digits',
                'cphonenumber.digits_between:8,15' => 'Enter Digits Between 8 to 15',
               
            );
             
            $validator = Validator::make($request->all(), $rules, $messsages);
            
            if($validator->fails()){ 
               // $user = new user;
                //print_r($validator->errors() );
                //exit;
                return redirect()->back()->withInput()->withErrors($validator);
            }
            else{
                $active_Company = DB::table('company')
               // ->where('company.priority','=',1)
                ->get(); 
               
                $user = new user;
                $user->companyid=$request->session()->get('companyid');
                $user->companycode=$request->session()->get('companycode');
                $user->fullname=$request->fullname;
                $user->displayname=$request->displayname;
                $user->gender=$request->gender;
                $user->phone=$request->phone;
                $user->otherphone=$request->otherphone;
                $user->designation=$request->designation;
                $user->email=$request->email;
                $user->password=Hash::make($request->password);
                $user->role=$request->role;
                $user->cpr=$request->cpr;
                $user->cprexpiry=date('Y-m-d',strtotime($request->cprexpiry));
                $user->dob=date('Y-m-d',strtotime($request->dob));
                $user->nationality=$request->nationality;
                $user->passportnumber=$request->passportnumber;
                $user->passportexpiry=date('Y-m-d',strtotime($request->passportexpiry));
                $user->visaexpiry=date('Y-m-d',strtotime($request->visaexpiry));
                $user->dl=$request->dl;
                $user->dlexpiry=date('Y-m-d',strtotime($request->dlexpiry));
                $user->paddress=$request->paddress;
                $user->pcity=$request->pcity;
                $user->pstate=$request->pstate;
                $user->pcountry=$request->pcountry;
                $user->ppost=$request->ppost;
                $user->pcountrycode=$request->pcountrycode;
                $user->pphonenumber=$request->pphonenumber;
                $user->caddress=$request->caddress;
                $user->ccity=$request->ccity;
                $user->cstate=$request->cstate;
                $user->ccountry=$request->ccountry;
                $user->cpost=$request->cpost;
                $user->ccountrycode=$request->ccountrycode;
                $user->cphonenumber=$request->cphonenumber;
                $user->status=1;
                $user->profile_picture='';
                $user->created_by=Auth::User()->id;
                $user->updated_by='';
                $user->created_at=date('Y-m-d H:i:s');
                $user->updated_at=date('Y-m-d H:i:s');

                $insert=$user->save();
                
                //print_r($insert);
                if($insert>0 ){
                    if($request->upload_dp!=''){
                        $file = $request->file;
                        $filetype=$request->upload_dp->getClientOriginalExtension();
                        
                        $destination = 'assets/img/profiles/user_profile/';
                        $imageName = $request->file('upload_dp')->getClientOriginalName();
                        $file = $request->file('upload_dp');
                        $filename = $user->id.'_displaypic.'.$file->getClientOriginalExtension();
                        $result=$request->file('upload_dp')->move($destination,  $filename);
                        
                        $user = User::find($user->id);
                        $user->profile_picture=$destination.$filename;
                        $user->image_type=$filetype;
                        $insertinside=$user->save();
                    }
                    $message='You Just created user "'.$request->fullname.'"';
                   // return redirect()->to($request->header('referer'). '?userid='.$user->id.'/#roles')->withInput(  ['tab' => 'roles','userid' => $user->id ] )->with(['userid' => $user->id ,'success' => $message]);
                   $data = \DB::table('users')->orderBy('users.displayname')->get();
                   $role = \DB::table('roles')->get();
                   //print_r($role);
                   //exit;
                   return view('pages.users.viewUser')->with(['data' => $data, 'role' => $role,'success' => $message]);
                   // return redirect()->back()->withInput(  ['tab' => 'basicdetails','userid' => $user->id ] )->with(['userid' => $user->id ,'success' => $message]);
                }
            }
        }
        
        
      
        
   
    public function updateUserRoleAjax(Request $request){
        $roleid=$_POST['roleselected'];
        $role = \DB::table('roles')
        ->where('roleid','=',$roleid)
        ->get();
        $rolePermission = \DB::table('role_permissions')
        ->where('roleid','=',$roleid)
        ->get();
        return array(['roleprm' => $rolePermission,'role' => $role]);

    }
    public function userStatusChangeAjax(Request $request){
       
        
        if($_POST['userstatus']=='deactive'){
            $result=DB::table('users')
            ->where('id', $_POST['userid'])
            ->update([
                'status'=>0,
            ]);   
        }
        else{
            $result=DB::table('users')
            ->where('id', $_POST['userid'])
            ->update([
                'status'=>1,
            ]);
        }
               
        return array(['success' => 'success']);
    }


    
    
    public function viewUser()
    {
        //$data = $this->User->getall();
        //print_r($data);
        $data = \DB::table('users')->orderBy('users.displayname')->get();
        $role = \DB::table('roles')->get();
        //print_r($role);
        //exit;
        return view('pages.users.viewUser')->with(['data' => $data, 'role' => $role]);
    }
    public function editUser($id){
        $id=Crypt::decrypt($id);
        $data=$this->User->getById($id);
        
        $role = \DB::table('roles')
        ->where('roleid','=',$data->role)
        ->get();

        $roleTable = \DB::table('roles')
        ->where('roleid','!=',1)
        ->where('status','=',1)
        ->get();
        $rolePermissions = \DB::table('role_permissions')->get();
        $active = 'User Management-user';
        return view('pages.users.editUser')->with(['data' => $data, 'role' => $role, 'roleTable' => $roleTable, 'rolePermissions' => $rolePermissions, 'active' => $active ] );

    }
    public function deleteUserDP(Request $request){
        
        $result=DB::table('users')
                ->where('id', $request->userid)
                ->update([
                    'profile_picture'=>'',
                    'image_type'=>'',
                ]);
                return array(['success' => 'success']);
    }
    public function editUserSave(Request $request){
             
        
        if ($request->has('form1')) {
           
        $rules = [
                'upload_dp' => 'nullable | image:jpeg,jpg,png | max:2097152',
                'fullname' => 'required|min:3|max:50',
                'displayname' => 'required|min:2|max:10',
                'gender' => 'required|in:"male","female"',
                'phone' => 'required|digits_between:8,15',
                'otherphone' => 'numeric|digits_between:8,15|nullable',
                'email' => 'required|email|unique:users,email,'.$request->id,
                'cpr' => 'numeric|digits:9|nullable',
                'cprexpiry' => 'date|nullable',
                'dob' => 'date|nullable',
                'passportexpiry' => 'date|nullable',
                'visaexpiry' => 'date|nullable',
                'dlexpiry' => 'date|nullable',
                'pcountrycode' => 'numeric|nullable',
                'pphonenumber' => 'numeric|digits_between:8,15|nullable',
                'ccountrycode' => 'numeric|nullable',
                'cphonenumber' => 'numeric|digits_between:8,15|nullable',
                
        ];
            $messsages = array(
                'upload_dp.image' => 'Upload image of type jpeg ,jpg or png' ,
                'upload_dp.max' => 'Max image size is 2 MB',
                'fullname.required' => 'Enter Full Name',
                'fullname.min' => 'Enter Minimum 3 character',
                'fullname.max' => 'Enter Max Limit 50 character',
                'displayname.required' => 'Enter Display Name',
                'displayname.min' => 'Enter Minimum 2 character',
                'displayname.max' => 'Enter Max Limit 10 character',
                'gender.required' => 'Select Gender',
                'phone.required' => 'Enter Phone Number',
                'phone.numeric' => 'Enter Numbers only',
                'phone.digits_between' => 'Enter Digits Between 8 to 15',
                'otherphone.numeric' => 'Enter Numbers only',
                'otherphone.digits_between' => 'Enter Digits Between 8 to 15',
                'email.required' => 'please Enter E-mail',
                'email.email' => 'Enter Valid E-mail',
                'email.unique' => 'E-mail already Exists',
                'cpr.numeric' => 'Enter Digits Only',
                'cpr.digits' => 'Enter only 9 Digits',
                'cprexpiry.date' => 'Enter Valid Date',
                'dob.date' => 'Enter Valid Date',
                'passportexpiry.date' => 'Enter Valid Date',
                'visaexpiry.date' => 'Enter Valid Date',
                'dlexpiry.date' => 'Enter Valid Date',
                'pcountrycode.numeric' => 'Enter only Digits',
                'pphonenumber.numeric' => 'Enter only Digits',
                'pphonenumber.digits_between' => 'Enter Digits Between 8 to 15',
                'ccountrycode.numeric' => 'Enter only Digits',
                'cphonenumber.numeric' => 'Enter only Digits',
                'cphonenumber.digits_between:8,13' => 'Enter Digits Between 8 to 15',
                
            );
             $validator = Validator::make($request->all(), $rules, $messsages);
            
            if($validator->fails()){ 
                //echo "validator Fails";
                print_r($validator->errors());
                
                return redirect()->back()->withInput()->withErrors($validator);
            
            
            }
            else{
                $useractive=0;
                if($request->useractive=='on'|| $request->useractive==true){
                    $useractive=1;
                }
                
                $result=DB::table('users')
                ->where('id', $request->id)
                ->update([
                'fullname'=>$request->fullname,
                'displayname'=>$request->displayname,
                'gender'=>$request->gender,
                'phone'=>$request->phone,
                'otherphone'=>$request->otherphone,
                'email'=>$request->email,
                'designation'=>$request->designation,
                'cpr'=>$request->cpr,
                'cprexpiry'=>date('Y-m-d',strtotime($request->cprexpiry)),
                'dob'=>date('Y-m-d',strtotime($request->dob)),
                'nationality'=>$request->nationality,
                'passportnumber'=>$request->passportnumber,
                'passportexpiry'=>date('Y-m-d',strtotime($request->passportexpiry)),
                'visaexpiry'=>date('Y-m-d',strtotime($request->visaexpiry)),
                'dl'=>$request->dl,
                'dlexpiry'=>date('Y-m-d',strtotime($request->dlexpiry)),
                'paddress'=>$request->paddress,
                'pcity'=>$request->pcity,
                'pstate'=>$request->pstate,
                'pcountry'=>$request->pcountry,
                'ppost'=>$request->ppost,
                'pcountrycode'=>$request->pcountrycode,
                'pphonenumber'=>$request->pphonenumber,
                'caddress'=>$request->caddress,
                'ccity'=>$request->ccity,
                'cstate'=>$request->cstate,
                'ccountry'=>$request->ccountry,
                'cpost'=>$request->cpost,
                'ccountrycode'=>$request->ccountrycode,
                'cphonenumber'=>$request->cphonenumber,
                'cphonenumber'=>$request->cphonenumber,
                //'status'=>$useractive,
                'updated_by'=>Auth::User()->id,
                'updated_at'=>date('Y-m-d H:i:s'),
                ]);
                
                //print_r($insert);
                
//print_r($_POST);
  //              //echo "display pic".$request->display_pic."<br>";
    //            exit;
    
                    if($request->upload_dp){
                        $file = $request->file;
                        $filetype=$request->upload_dp->getClientOriginalExtension();
                        
                        $destination = 'assets/img/profiles/user_profile/';
                        $imageName = $request->file('upload_dp')->getClientOriginalName();
                        $file = $request->file('upload_dp');
                        $filename = $request->id.'_displaypic.'.$file->getClientOriginalExtension();
                        $result=$request->file('upload_dp')->move($destination,  $filename);
                        
                        $user = User::find($request->id);
                        $user->profile_picture=$destination.$filename;
                        $user->image_type=$filetype;
                        $insertinside=$user->save();
                    }
                    else{
                    }
                    $data = $this->User->getall();
                    $role = \DB::table('roles')->get();
                    $message='You Just Edited '.$request->fullname.' Profile';
                    return redirect()->route('view.user')->with(['data' => $data, 'role' => $role])->with('success',$message);
                }
            }
        
            if ($request->has('form2')) {
              
                $result=DB::table('users')
                    ->where('id', $_POST['userid'])
                    ->update([
                    'role'=>$_POST['roleselect']
                    ]);

                    $data = $this->User->getall();
                    $role = \DB::table('roles')->get();
                    $message='Role Updated';
                    return redirect()->route('view.user')->with(['data' => $data, 'role' => $role])->with('success',$message);
                    //return redirect('/createUser')->with(['success' => 'Role Updated']);
            }
        }
              
    
    
    public function searchForUserajax(Request $request){
        
        $search=$_POST['searchString'];
        //if($search!=''){
            $datauser=DB::table('users')
            ->orwhere('fullname', 'LIKE', '%' . $search . '%')
            ->orWhere('displayname', 'LIKE', '%' . $search . '%')
            ->orWhere('email', 'LIKE', '%' . $search . '%')
            ->orWhere('phone', 'LIKE', '%' . $search . '%')
            ->orderBy('displayname', 'asc')
            ->get();
       /* }
        else{
            $datauser = $this->User->getall();
        } */
         $role = \DB::table('roles')->get();
         //return redirect()->route('view.user')->withInput()->with(['data' => $data, 'role' => $role]);
         return array(['data' => $datauser, 'role' => $role]);
 
     }
    

    
    
}