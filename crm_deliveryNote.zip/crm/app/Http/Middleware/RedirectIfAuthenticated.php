<?php

namespace App\Http\Middleware;

use Closure;
use Cookie;
use Hash;
use Illuminate\Support\Facades\Auth;

class RedirectIfAuthenticated
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @param  string|null  $guard
     * @return mixed
     */
    public function handle($request, Closure $next, $guard = null)
    {
        
     //echo $request->path();     
       if ( Auth::check() ) {
            
            return redirect('/dashboard');
        }
       else{
          
            if(\Cookie::get('email')!='' ){
               
               return redirect('/logout');
            }
            else{
               return $next($request);   
            }
                                      
           }
            
    }   

}
