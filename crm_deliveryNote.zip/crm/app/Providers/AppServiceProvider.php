<?php

namespace App\Providers;
use Path;
use Illuminate\Support\ServiceProvider;

use App\Repositories\UserRepository;
use App\Repositories\EloquentUser;

use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Config; 

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    { 
       
/*
        if ( \Schema::hasTable('users') && \Schema::hasTable('roles') && \Schema::hasTable('role_permissions') ){ 
            //if(Auth::check()){
            $user_role_permission='';
            $user_role_permission = DB::table('users')
                ->join('roles', 'users.role', '=', 'roles.roleid')
                ->join('role_permissions', 'roles.roleid', '=', 'role_permissions.roleid')
                ->join('company', 'company.id', '=', 'users.companyid')
                ->where('users.status','=',1)
                //->where('users.email','=',Auth::user()->email)
                //->where('users.companyid','=',Auth::user()->companyid)
                ->select('users.*', 'roles.*', 'role_permissions.*')
                ->get();

                define("GREETING", $user_role_permission);
                view()->composer('*', function ($view) 
                {
                    $view->with('logedInuser', GREETING);   
                    $view->with('dashboardMenu', Config::get('sidebarMenu') );
                });
            //} 
        }
         // print_r($user_role_permission);
           //exit;   */
    }
    
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //$this->app->singleton(TaskRepository::class, Repository::class);
        $this->app->singleton(UserRepository::class, EloquentUser::class);

    }
}
