<?php
 
namespace App\Repositories;
 
use App\Model\User;
use App\Model\Role;
 
class EloquentUser implements UserRepository
{
	/**
	 * @var $model
	 */
	private $user;
	private $role;
	
 
	/**
	 * EloquentTask constructor.
	 *
	 * @param App\User $model
	 */
	public function __construct(User $user,Role $role)
	{
		$this->user = $user;
		$this->role = $role;
	}
 
	/**
	 * Get all tasks.
	 *
	 * @return Illuminate\Database\Eloquent\Collection
	 */
	public function getAll()
	{
		return $this->user->all();
	}
 
	/**
	 * Get task by id.
	 *
	 * @param integer $id
	 *
	 * @return App\Task
	 */
	public function getById($id)
	{
		return $this->user->find($id);
	}
 
	/**
	 * Create a new task.
	 *
	 * @param array $attributes
	 *
	 * @return App\Task
	 */
	public function create(array $attributes)
	{
		return $this->model->create($attributes);
	}
 
	/**
	 * Update a task.
	 *
	 * @param integer $id
	 * @param array $attributes
	 *
	 * @return App\Task
	 */
	public function update($id, array $attributes)
	{
		return $this->model->find($id)->update($attributes);
	}
 
	/**
	 * Delete a task.
	 *
	 * @param integer $id
	 *
	 * @return boolean
	 */
	public function delete($id)
	{
		return $this->model->find($id)->delete();
	}

	/**
	 * This is to send information to header bar.
	 *
	 * @param integer $id
	 *
	 * @return boolean
	 */
	public function userdetails_headerbar($id)
	{
		$id=Auth::user()->id;
		return $this->model->find($id)->list();
	}
}